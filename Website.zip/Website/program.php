<?php
session_start();

// 1. Protection Security Check
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// 2. Include database configuration file
require_once 'db.php';

// Route Parameter Handlers
$action = isset($_GET['action']) ? trim($_GET['action']) : 'view';
$prog_id = isset($_GET['id']) ? trim($_GET['id']) : ''; 

/* ==========================================
   STATE TRACKING & SQL CONTEXT BINDING (PURE PHP)
   ========================================== */
$selected_school_id = isset($_POST['school_selector_val']) ? intval($_POST['school_selector_val']) : (isset($_GET['school_id']) ? intval($_GET['school_id']) : 0);
$selected_dept_id = isset($_POST['dept_selector_val']) ? intval($_POST['dept_selector_val']) : (isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0);

// Show directory grid if user explicitly clicks Next/Select or returns from a redirect state
$show_directory = isset($_POST['click_next_dept']) || isset($_POST['select_dept_btn']) || (isset($_GET['show']) && $_GET['show'] === 'true');

$message = '';
$message_type = '';

/* ==========================================
   POST ACTIONS HANDLER BLOCK
   ========================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ACTION A: SAVE NEW PROGRAM ENTRY
    if (isset($_POST['save_program'])) {
        $progid = isset($_POST['progid']) ? trim($_POST['progid']) : '';
        $progfullname = isset($_POST['progfullname']) ? trim($_POST['progfullname']) : '';
        $progshortname = isset($_POST['progshortname']) ? trim($_POST['progshortname']) : '';
        $progcolldeptid = isset($_POST['progcolldeptid']) ? intval($_POST['progcolldeptid']) : 0;

        if (empty($progid) || empty($progfullname) || $progcolldeptid <= 0 || $selected_school_id <= 0) {
            $message = "Program ID, Full Name, and valid School/Department context assignments are required.";
            $message_type = "error";
            $action = "create";
        } else {
            try {
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM programs WHERE progid = ?");
                $check_stmt->execute([$progid]);

                if ($check_stmt->fetchColumn() > 0) {
                    $message = "Conflict: A program entry with ID '{$progid}' already exists in the registry.";
                    $message_type = "error";
                    $action = "create";
                } else {
                    $insert_stmt = $pdo->prepare("INSERT INTO programs (progid, progfullname, progshortname, progcollid, progcolldeptid) VALUES (?, ?, ?, ?, ?)");
                    $insert_stmt->execute([$progid, $progfullname, $progshortname, $selected_school_id, $progcolldeptid]);
                    
                    header("Location: program.php?school_id=" . $selected_school_id . "&dept_id=" . $progcolldeptid . "&show=true");
                    exit;
                }
            } catch (\PDOException $e) {
                $message = "Database transactional error: " . $e->getMessage();
                $message_type = "error";
                $action = "create";
            }
        }
    }

    // ACTION B: UPDATE EXISTING PROGRAM ENTRY
    if (isset($_POST['update_program'])) {
        $old_progid = isset($_POST['old_progid']) ? trim($_POST['old_progid']) : '';
        $new_progid = isset($_POST['progid']) ? trim($_POST['progid']) : '';
        $progfullname = isset($_POST['progfullname']) ? trim($_POST['progfullname']) : '';
        $progshortname = isset($_POST['progshortname']) ? trim($_POST['progshortname']) : '';
        $progcolldeptid = isset($_POST['progcolldeptid']) ? intval($_POST['progcolldeptid']) : 0;

        if (empty($new_progid) || empty($progfullname) || $progcolldeptid <= 0 || $selected_school_id <= 0) {
            $message = "Program ID, Full Name, and valid School/Department context assignments are required.";
            $message_type = "error";
            $action = "update";
            $prog_id = $old_progid;
        } else {
            try {
                if ($old_progid !== $new_progid) {
                    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM programs WHERE progid = ?");
                    $check_stmt->execute([$new_progid]);
                    if ($check_stmt->fetchColumn() > 0) {
                        throw new Exception("Conflict: The new Program ID '{$new_progid}' is already assigned to a different program.");
                    }
                }

                $update_stmt = $pdo->prepare("
                    UPDATE programs 
                    SET progid = ?, progfullname = ?, progshortname = ?, progcollid = ?, progcolldeptid = ? 
                    WHERE progid = ?
                ");
                $update_stmt->execute([$new_progid, $progfullname, $progshortname, $selected_school_id, $progcolldeptid, $old_progid]);
                
                header("Location: program.php?school_id=" . $selected_school_id . "&dept_id=" . $progcolldeptid . "&show=true");
                exit;
            } catch (\Exception $e) {
                $message = "Update operation error: " . $e->getMessage();
                $message_type = "error";
                $action = "update";
                $prog_id = $old_progid;
            }
        }
    }

    // ACTION C: CONFIRM DELETE PROGRAM RECORD
    if (isset($_POST['confirm_delete_prog'])) {
        try {
            $check_students = $pdo->prepare("SELECT COUNT(*) FROM students WHERE studprogid = ?");
            $check_students->execute([$prog_id]);

            if ($check_students->fetchColumn() > 0) {
                $message = "Cannot remove this program entry. Active student profiles are currently enrolled under it.";
                $message_type = "error";
                $action = "delete";
            } else {
                $delete_stmt = $pdo->prepare("DELETE FROM programs WHERE progid = ?");
                $delete_stmt->execute([$prog_id]);
                header("Location: program.php?school_id=" . $selected_school_id . "&dept_id=" . $selected_dept_id . "&show=true");
                exit;
            }
        } catch (\PDOException $e) {
            $message = "Database delete operation failure: " . $e->getMessage();
            $message_type = "error";
            $action = "delete";
        }
    }
}

/* ==========================================
   DATA LOOKUP RESOLUTION BLOCK (GET ROUTING)
   ========================================== */
$schools = [];
$filtered_departments = [];
$programs = [];
$program_data = null;
$selected_school_info = null;
$selected_dept_info = null;

try {
    $schools_stmt = $pdo->query("SELECT collid, collfullname, collshortname FROM colleges ORDER BY collfullname ASC");
    $schools = $schools_stmt->fetchAll();

    if ($selected_school_id > 0) {
        $dept_stmt = $pdo->prepare("SELECT deptid, deptfullname, deptshortname, deptcollid FROM departments WHERE deptcollid = ? ORDER BY deptfullname ASC");
        $dept_stmt->execute([$selected_school_id]);
        $filtered_departments = $dept_stmt->fetchAll();
        
        foreach ($schools as $s) {
            if ($s['collid'] == $selected_school_id) {
                $selected_school_info = $s;
                break;
            }
        }
    }
} catch (\PDOException $e) {
    die("Core database component mapping failed: " . $e->getMessage());
}

if ($selected_dept_id > 0 && count($filtered_departments) > 0) {
    foreach ($filtered_departments as $d) {
        if ($d['deptid'] == $selected_dept_id) {
            $selected_dept_info = $d;
            break;
        }
    }
}

if (($action === 'delete' || $action === 'update') && !empty($prog_id)) {
    $stmt = $pdo->prepare("SELECT * FROM programs WHERE progid = ?");
    $stmt->execute([$prog_id]);
    $program_data = $stmt->fetch();
    if (!$program_data) {
        header("Location: program.php");
        exit;
    }
    $selected_dept_id = $program_data['progcolldeptid'];
    $selected_school_id = $program_data['progcollid'];
}

if ($action === 'view' && $selected_school_id > 0 && $selected_dept_id > 0 && $show_directory) {
    try {
        $prog_list_stmt = $pdo->prepare("
            SELECT progid, progfullname, progshortname 
            FROM programs 
            WHERE progcollid = ? AND progcolldeptid = ? 
            ORDER BY progid ASC
        ");
        $prog_list_stmt->execute([$selected_school_id, $selected_dept_id]);
        $programs = $prog_list_stmt->fetchAll();
    } catch (\PDOException $e) {
        die("Programs matrix loader exception: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USJ-R School Management System v1.01</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background-color: #f8f9fa; color: #333; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        /* Navbar Layout */
        .navbar { background-color: #1a252f; color: #ffffff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        .btn-logout { background-color: #e74c3c; color: white; padding: 6px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; }

        /* Fixed Split-Screen Master Frame Layout */
        .dashboard-wrapper { display: flex; flex: 1; height: calc(100vh - 62px); }
        
        /* Exact Sidebar Match with department.php */
        .sidebar { width: 260px; background-color: #f0f4f8; border-right: 1px solid #dcdfe4; padding-top: 20px; }
        .sidebar-menu { list-style: none; }
        .sidebar-menu li a { display: block; padding: 14px 25px; color: #1a252f; text-decoration: none; font-size: 18px; font-weight: 500; }
        .sidebar-menu li a:hover, .sidebar-menu li.active a { background-color: #e2e8f0; color: #1abc9c; font-weight: 600; }

        /* Fixed Main Content Window Shell Layout */
        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        
        .panel-title { font-size: 22px; font-weight: bold; color: #000; margin-bottom: 25px; }
        .wizard-row { display: flex; align-items: center; gap: 10px; margin-bottom: 15px; }
        .select-filter-control { width: 450px; padding: 8px 10px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px; background-color: #fff; }
        .select-filter-control:disabled { background-color: #f5f5f5; color: #aaa; }
        
        .btn-green-submit { background-color: #5cb85c; color: white; border: none; padding: 8px 18px; border-radius: 4px; font-size: 14px; cursor: pointer; font-weight: bold; }
        .btn-green-submit:hover { background-color: #4cae4c; }
        .btn-green-submit:disabled { background-color: #ccc; cursor: not-allowed; }

        .form-row { display: flex; align-items: center; margin-bottom: 15px; max-width: 800px; }
        .form-label { width: 200px; font-size: 15px; font-weight: bold; color: #000; }
        .form-control { flex: 1; padding: 8px 12px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px; }
        .form-actions-bar { display: flex; gap: 10px; margin-top: 25px; padding-left: 200px; }

        .header-context-title { background-color: #fff; font-size: 15px; font-weight: bold; color: #000; margin-bottom: 15px; }
        .btn-action-trigger { background-color: #5cb85c; color: white; padding: 6px 14px; border-radius: 4px; font-weight: bold; text-decoration: none; display: inline-block; margin-bottom: 15px; font-size: 13px; border: none; }
        .btn-red-back { background-color: #d9534f; color: white; padding: 6px 14px; border-radius: 4px; font-weight: bold; text-decoration: none; display: inline-block; margin-bottom: 15px; font-size: 13px; margin-left: 5px; }

        .data-table { width: 100%; border-collapse: collapse; background-color: #fff; margin-top: 5px; }
        .data-table th { background-color: #5cb85c; color: white; text-align: left; padding: 10px 12px; font-size: 14px; font-weight: bold; }
        .data-table td { padding: 10px 12px; border-bottom: 1px solid #ddd; font-size: 14px; color: #000; }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        .btn-grid-action { padding: 4px 10px; border-radius: 3px; text-decoration: none; font-weight: bold; font-size: 12px; color: white; display: inline-block; margin-right: 5px; border: none; }
        .btn-grid-update { background-color: #5cb85c; }
        .btn-grid-delete { background-color: #d9534f; }
        
        .btn-submit-form { background-color: #fff; color: #333; border: 1px solid #ccc; padding: 8px 20px; border-radius: 4px; cursor: pointer; }
        .btn-cancel-form { background-color: #d9534f; color: #fff; padding: 8px 20px; border-radius: 4px; text-decoration: none; font-weight: bold; }

        .confirmation-box { background-color: #fff; border: 1px solid #ddd; padding: 20px; max-width: 600px; border-radius: 4px; }
        .alert-banner { padding: 10px 15px; border-radius: 4px; margin-bottom: 15px; font-size: 13px; font-weight: bold; max-width: 800px; }
        .alert-banner.error { background-color: #f2dede; color: #a94442; border: 1px solid #ebccd1; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <div class="user-status-area">
            <span>You are logged in as: <strong>admin</strong></span>
            <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
        </div>
    </header>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="dashboard.php?view=schools">Schools</a></li>
                <li><a href="department.php">Departments</a></li>
                <li class="active"><a href="program.php">Programs</a></li>
                <li><a href="students.php">Students</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                <li><a href="users.php">Users</a></li>
                <?php endif; ?>
            </ul>
        </aside>

        <main class="main-content">
            
            <?php if (!empty($message)): ?>
                <div class="alert-banner <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($action === 'create'): ?>
                <div class="panel-title">Program Create</div>
                <form action="program.php?action=create" method="POST">
                    <input type="hidden" name="school_selector_val" value="<?php echo $selected_school_id; ?>">
                    <input type="hidden" name="dept_selector_val" value="<?php echo $selected_dept_id; ?>">

                    <div class="form-row">
                        <label class="form-label">Parent Department:</label>
                        <select class="form-control" name="progcolldeptid" required>
                            <?php if ($selected_dept_id > 0 && $selected_dept_info): ?>
                                <option value="<?php echo $selected_dept_info['deptid']; ?>" selected>
                                    <?php echo htmlspecialchars($selected_dept_info['deptfullname']); ?> (ID: <?php echo $selected_dept_info['deptid']; ?>)
                                </option>
                            <?php else: ?>
                                <option value="" disabled selected>-- Select Parent Department --</option>
                                <?php foreach ($filtered_departments as $dept): ?>
                                    <option value="<?php echo $dept['deptid']; ?>">
                                        <?php echo htmlspecialchars($dept['deptfullname']); ?> (ID: <?php echo $dept['deptid']; ?>)
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <label class="form-label" for="progid">Program ID:</label>
                        <input class="form-control" type="text" id="progid" name="progid" placeholder="Enter Program ID Sequence" value="<?php echo isset($_POST['progid']) ? htmlspecialchars($_POST['progid']) : ''; ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="progfullname">Program Full Name:</label>
                        <input class="form-control" type="text" id="progfullname" name="progfullname" value="<?php echo isset($_POST['progfullname']) ? htmlspecialchars($_POST['progfullname']) : ''; ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="progshortname">Program Short Name:</label>
                        <input class="form-control" type="text" id="progshortname" name="progshortname" placeholder="(Optional)" value="<?php echo isset($_POST['progshortname']) ? htmlspecialchars($_POST['progshortname']) : ''; ?>" autocomplete="off">
                    </div>

                    <div class="form-actions-bar">
                        <button class="btn-submit-form" type="submit" name="save_program">Save New Program Entry</button>
                        <a class="btn-cancel-form" href="program.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&show=true">Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'update' && $program_data): ?>
                <div class="panel-title">Program Update</div>
                <form action="program.php?action=update" method="POST">
                    <input type="hidden" name="school_selector_val" value="<?php echo $selected_school_id; ?>">
                    <input type="hidden" name="dept_selector_val" value="<?php echo $selected_dept_id; ?>">
                    <input type="hidden" name="old_progid" value="<?php echo htmlspecialchars($program_data['progid']); ?>">

                    <div class="form-row">
                        <label class="form-label" for="progid">Program ID:</label>
                        <input class="form-control" type="text" id="progid" name="progid" value="<?php echo htmlspecialchars($program_data['progid']); ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="progfullname">Program Full Name:</label>
                        <input class="form-control" type="text" id="progfullname" name="progfullname" value="<?php echo htmlspecialchars($program_data['progfullname']); ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="progshortname">Program Short Name:</label>
                        <input class="form-control" type="text" id="progshortname" name="progshortname" value="<?php echo htmlspecialchars($program_data['progshortname']); ?>" autocomplete="off">
                    </div>

                    <div class="form-actions-bar">
                        <button class="btn-submit-form" type="submit" name="update_program" style="background-color: #5cb85c; color: white;">Update Program Entry</button>
                        <a class="btn-cancel-form" href="program.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&show=true">Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'delete'): ?>
                <div class="panel-title">Delete Program Confirmation</div>
                <div class="confirmation-box">
                    <p style="margin-bottom: 10px;">Are you sure you want to delete the following record?</p>
                    <p><strong>ID:</strong> <?php echo htmlspecialchars($program_data['progid']); ?></p>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($program_data['progfullname']); ?></p>
                    <br>
                    <form action="program.php?action=delete&id=<?php echo urlencode($prog_id); ?>&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&show=true" method="POST">
                        <button type="submit" name="confirm_delete_prog" class="btn-cancel-green" style="background-color:#d9534f; color:white; border:none; padding:8px 15px; cursor:pointer; border-radius:4px; font-weight:bold;">Yes, Confirm Delete</button>
                        <a href="program.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&show=true" style="background-color:#5cb85c; color:white; padding:8px 15px; text-decoration:none; border-radius:4px; font-weight:bold; margin-left:10px; display:inline-block;">No, Cancel</a>
                    </form>
                </div>

            <?php else: ?>
                
                <?php if (!$show_directory || $selected_school_id <= 0 || $selected_dept_id <= 0): ?>
                    <div class="panel-title">Select School and Department</div>

                    <form action="program.php" method="POST">
                        <div class="wizard-row">
                            <select class="select-filter-control" name="school_selector_val" onchange="this.form.submit();" required>
                                <option value="" disabled <?php echo ($selected_school_id === 0) ? 'selected' : ''; ?>>Select School</option>
                                <?php foreach ($schools as $school): ?>
                                    <option value="<?php echo $school['collid']; ?>" <?php echo ($selected_school_id === (int)$school['collid']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($school['collfullname']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn-green-submit" name="select_school_btn" <?php echo ($selected_school_id > 0) ? 'style="background-color:#ccc;" disabled' : ''; ?>>Select School</button>
                        </div>
                    </form>

                    <form action="program.php" method="POST">
                        <input type="hidden" name="school_selector_val" value="<?php echo $selected_school_id; ?>">
                        <div class="wizard-row">
                            <select class="select-filter-control" name="dept_selector_val" <?php echo ($selected_school_id === 0) ? 'disabled' : ''; ?> required>
                                <option value="" disabled <?php echo ($selected_dept_id === 0) ? 'selected' : ''; ?>>Select Department</option>
                                <?php foreach ($filtered_departments as $dept): ?>
                                    <option value="<?php echo $dept['deptid']; ?>" <?php echo ($selected_dept_id === (int)$dept['deptid']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($dept['deptfullname']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn-green-submit" name="select_dept_btn" <?php echo ($selected_school_id === 0) ? 'disabled' : ''; ?>>Select Department</button>
                            <?php if ($selected_school_id > 0): ?>
                                <a href="program.php" class="btn-red-back" style="margin:0; padding:8px 15px;">Back</a>
                            <?php endif; ?>
                        </div>
                    </form>

                <?php endif; ?>

                <?php if ($selected_school_id > 0 && $selected_dept_id > 0 && $selected_school_info && $selected_dept_info && $show_directory): ?>
                    
                    <div class="header-context-title">
                        Program List - <?php echo htmlspecialchars($selected_school_info['collfullname']); ?> | <?php echo htmlspecialchars($selected_dept_info['deptfullname']); ?>
                    </div>

                    <a href="program.php?action=create&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>" class="btn-action-trigger">⊕ Create Program Entry</a>
                    <a href="program.php" class="btn-red-back">🗙 Back</a>

                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 20%;">Program ID</th>
                                <th style="width: 50%;">Program Full Name</th>
                                <th style="width: 15%;">Program Short Name</th>
                                <th style="width: 15%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($programs) > 0): ?>
                                <?php foreach ($programs as $prog): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($prog['progid']); ?></td>
                                        <td><?php echo htmlspecialchars($prog['progfullname']); ?></td>
                                        <td><?php echo htmlspecialchars(!empty($prog['progshortname']) ? $prog['progshortname'] : '—'); ?></td>
                                        <td>
                                            <a href="program.php?action=update&id=<?php echo urlencode($prog['progid']); ?>" class="btn-grid-action btn-grid-update">Update</a>
                                            <a href="program.php?action=delete&id=<?php echo urlencode($prog['progid']); ?>" class="btn-grid-action btn-grid-delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" style="text-align: center; color: #aaa; padding: 20px;">No program entries exist for this selection.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

</body>
</html>