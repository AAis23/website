<?php
session_start();

// If the user is already logged in, redirect them to the dashboard automatically
if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit;
}

$error_message = '';
$csv_file_path = 'users.csv';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $input_username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $input_password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($input_username) || empty($input_password)) {
        $error_message = "Please enter both username and password.";
    } else {
        $authenticated = false;
        $matched_user = null;

        // Check if the CSV database file exists
        if (file_exists($csv_file_path)) {
            // Open the file with PHP 8.4 explicit escape defaults to clear deprecation notices
            if (($handle = fopen($csv_file_path, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ",", '"', "\\")) !== FALSE) {
                    // Skip empty or corrupted lines
                    if (empty($data) || $data === [null] || count($data) < 4) {
                        continue;
                    }

                    // CSV Column Mapping:
                    // Index 0: ID
                    // Index 1: User Name
                    // Index 2: Password
                    // Index 3: Role
                    $csv_username = trim($data[1]);
                    $csv_password = trim($data[2]);

                    // Perform a strict case-insensitive check for the username, and direct check for password
                    if (strtolower($csv_username) === strtolower($input_username) && $csv_password === $input_password) {
                        $authenticated = true;
                        $matched_user = [
                            'id'       => trim($data[0]),
                            'username' => $csv_username,
                            'role'     => trim($data[3])
                        ];
                        break; // Stop looking through the file once found
                    }
                }
                fclose($handle);
            } else {
                $error_message = "System Error: Unable to open the user registry data file.";
            }
        } else {
            $error_message = "No user records found. Please use the system's initialization features or upload a file first.";
        }

        // Handle successful match logic
        if ($authenticated && $matched_user !== null) {
            // Establish the session variables expected by your guard filters across your scripts
            $_SESSION['user'] = $matched_user['username'];
            $_SESSION['role'] = $matched_user['role'];
            $_SESSION['user_id'] = $matched_user['id'];

            // Redirect to your central dashboard view panel
            header("Location: dashboard.php");
            exit;
        } else if (empty($error_message)) {
            $error_message = "Invalid Username or Password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - USJ-R School Management System</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background-color: #f8f9fa; display: flex; justify-content: center; align-items: center; height: 100vh; }
        
        .login-container { background-color: #ffffff; border: 1px solid #dcdfe4; border-radius: 8px; padding: 40px; width: 100%; max-width: 400px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05); }
        .system-title { text-align: center; font-size: 20px; font-weight: bold; color: #1a252f; margin-bottom: 25px; text-transform: uppercase; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 14px; font-weight: bold; margin-bottom: 8px; color: #333; }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        .form-control:focus { border-color: #5cb85c; outline: none; }
        
        .btn-login { width: 100%; background-color: #5cb85c; color: white; border: 1px solid #4cae4c; padding: 12px; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        .btn-login:hover { background-color: #4cae4c; }
        
        .alert-danger { background-color: #f2dede; color: #a94442; border: 1px solid #ebccd1; padding: 12px; border-radius: 4px; font-size: 14px; margin-bottom: 20px; text-align: center; font-weight: bold; }
    </style>
</head>
<body>

    <div class="login-container">
        <h2 class="system-title">USJ-R System Login</h2>

        <?php if (!empty($error_message)): ?>
            <div class="alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" class="form-control" placeholder="Enter your username" required autocomplete="off">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>

            <button type="submit" name="login" class="btn-login">Log In</button>
        </form>
    </div>

</body>
</html>