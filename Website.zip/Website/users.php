<?php
session_start();

// 1. Authenticated Guard Check: Kick unauthenticated sessions back to login page
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// 2. Role Authorization Guard Check: Block standard users from accessing the user dashboard area entirely
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Administrator') {
    // Redirect them back to the main landing dashboard with an access error notice
    header("Location: dashboard.php?error=unauthorized_access");
    exit;
}

// Router Parameter Handler
$action = isset($_GET['action']) ? trim($_GET['action']) : 'view';

$message = '';
$message_type = '';
$users_list = [];
$processing_errors = []; 
$csv_file_path = 'users.csv';

/* ==========================================
   STATE 1: UPLOAD & PROCESS 4-COLUMN CSV FILE WITH DUPLICATE SKIP FILTERS
   ========================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_csv'])) {
    if ($_SESSION['role'] === 'Administrator') {
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['csv_file']['tmp_name'];
            $file_name = $_FILES['csv_file']['name'];
            
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if ($file_ext !== 'csv') {
                $message = "Invalid format. Please upload a valid .csv file.";
                $message_type = "error";
            } else {
                $existing_usernames = [];
                if (file_exists($csv_file_path)) {
                    if (($check_handle = fopen($csv_file_path, "r")) !== FALSE) {
                        while (($existing_data = fgetcsv($check_handle, 1000, ",", '"', "\\")) !== FALSE) {
                            if (isset($existing_data[1])) {
                                $existing_usernames[strtolower(trim($existing_data[1]))] = true;
                            }
                        }
                        fclose($check_handle);
                    }
                }

                if (($source_handle = fopen($file_tmp, "r")) !== FALSE) {
                    if (($dest_handle = fopen($csv_file_path, "a")) !== FALSE) {
                        
                        $inserted_count = 0;
                        $has_skips = false;

                        while (($data = fgetcsv($source_handle, 1000, ",", '"', "\\")) !== FALSE) {
                            if (count($data) >= 4) {
                                $user_id   = trim($data[0]);
                                $username  = trim($data[1]);
                                $password  = trim($data[2]);
                                $user_role = trim($data[3]);

                                if (strtolower($user_id) === 'id' || strtolower($username) === 'user name') {
                                    continue;
                                }

                                $lookup_username = strtolower($username);

                                if (isset($existing_usernames[$lookup_username])) {
                                    $processing_errors[] = "User already exists: " . htmlspecialchars($username) . ". Skipping insertion.";
                                    $has_skips = true;
                                    continue; 
                                }

                                fputcsv($dest_handle, [$user_id, $username, $password, $user_role], ",", '"', "\\");
                                $existing_usernames[$lookup_username] = true;
                                $inserted_count++;
                            }
                        }
                        fclose($dest_handle);
                        fclose($source_handle);

                        if ($inserted_count > 0) {
                            $message = "Successfully uploaded and parsed {$inserted_count} user entries!";
                            $message_type = "success";
                        }
                        
                        if ($has_skips && $inserted_count === 0) {
                            $message = "File processed with some errors. Please review the error messages.";
                            $message_type = "error";
                        }
                    } else {
                        fclose($source_handle);
                        $message = "Error: System cannot write to storage file data layer.";
                        $message_type = "error";
                    }
                } else {
                    $message = "Error opening the uploaded file template layer.";
                    $message_type = "error";
                }
            }
        } else {
            $message = "Please select a valid CSV file before clicking upload.";
            $message_type = "error";
        }
    }
}

/* ==========================================
   STATE 2: READ FLAT FILE DATABASE FOR DISPLAY MATRIX
   ========================================== */
if ($action === 'manage') {
    if (file_exists($csv_file_path)) {
        if (($handle = fopen($csv_file_path, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",", '"', "\\")) !== FALSE) {
                if (empty($data) || $data === [null] || count($data) < 4) {
                    continue;
                }

                $id       = trim($data[0]);
                $username = trim($data[1]);
                $role     = trim($data[3]); 

                $users_list[] = [
                    'id'       => $id,
                    'username' => $username,
                    'type'     => ($role === 'Administrator') ? 'Administrator' : 'User',
                ];
            }
            fclose($handle);
        } else {
            $message = "Error: Unable to open the CSV file store.";
            $message_type = "error";
        }
    }
}

/* ==========================================
   STATE 3: SETTINGS WORKFLOW FOR FLAT-FILE REGISTRY
   ========================================== */
$edit_user = null;

if ($action === 'settings' && isset($_GET['id']) && $_SESSION['role'] === 'Administrator') {
    $target_id = trim($_GET['id']);
    $all_records = [];

    if (file_exists($csv_file_path)) {
        if (($handle = fopen($csv_file_path, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",", '"', "\\")) !== FALSE) {
                if (empty($data) || $data === [null]) continue;
                
                $all_records[] = $data;
                if (trim($data[0]) === $target_id) {
                    $edit_user = [
                        'id'       => trim($data[0]),
                        'username' => trim($data[1]),
                        'password' => trim($data[2]),
                        'role'     => trim($data[3])
                    ];
                }
            }
            fclose($handle);
        }
    }

    if (!$edit_user) {
        header("Location: users.php?action=manage&status=error_not_found");
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
        $new_username = trim($_POST['new_username']);
        $new_password = $_POST['new_password'];
        $new_role     = trim($_POST['new_role']);

        if (empty($new_username)) {
            $message = "Username target parameter field cannot be empty.";
            $message_type = "error";
        } else {
            if (($write_handle = fopen($csv_file_path, "w")) !== FALSE) {
                foreach ($all_records as $record) {
                    if ($record[0] === $target_id) {
                        $final_password = !empty($new_password) ? $new_password : $record[2];
                        fputcsv($write_handle, [$target_id, $new_username, $final_password, $new_role], ",", '"', "\\");
                    } else {
                        fputcsv($write_handle, $record, ",", '"', "\\");
                    }
                }
                fclose($write_handle);
                header("Location: users.php?action=manage&status=success_update");
                exit;
            } else {
                $message = "File access locked. System unable to commit data changes.";
                $message_type = "error";
            }
        }
    }
}

/* ==========================================
   STATE 4: DELETE ACTION WORKFLOW FOR FLAT-FILE REGISTRY
   ========================================== */
if ($action === 'delete' && isset($_GET['id']) && $_SESSION['role'] === 'Administrator') {
    $target_id = trim($_GET['id']);
    $all_records = [];
    $user_deleted = false;
    $self_delete_blocked = false;

    if (file_exists($csv_file_path)) {
        if (($handle = fopen($csv_file_path, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",", '"', "\\")) !== FALSE) {
                if (empty($data) || $data === [null]) continue;
                
                if (trim($data[0]) === $target_id) {
                    if (isset($_SESSION['user']) && strtolower(trim($data[1])) === strtolower(trim($_SESSION['user']))) {
                        $self_delete_blocked = true;
                        $all_records[] = $data; 
                        continue;
                    }
                    $user_deleted = true; 
                } else {
                    $all_records[] = $data;
                }
            }
            fclose($handle);
        }

        if ($self_delete_blocked) {
            header("Location: users.php?action=manage&status=error_self_delete");
            exit;
        } elseif ($user_deleted) {
            if (($write_handle = fopen($csv_file_path, "w")) !== FALSE) {
                foreach ($all_records as $record) {
                    fputcsv($write_handle, $record, ",", '"', "\\");
                }
                fclose($write_handle);
                header("Location: users.php?action=manage&status=success_delete");
                exit;
            } else {
                $message = "File access locked. Unable to update the registry data layer.";
                $message_type = "error";
            }
        } else {
            header("Location: users.php?action=manage&status=error_not_found");
            exit;
        }
    }
}

// Handle All Redirection Feedback Notice Status Messages
if (isset($_GET['status'])) {
    if ($_GET['status'] === 'success_update') {
        $message = "User account profile settings modified and saved successfully.";
        $message_type = "success";
    } elseif ($_GET['status'] === 'success_delete') {
        $message = "User account profile has been permanently removed from the system.";
        $message_type = "success";
    } elseif ($_GET['status'] === 'error_self_delete') {
        $message = "Operation Denied: You cannot delete your own active administrative account session.";
        $message_type = "error";
    } elseif ($_GET['status'] === 'error_not_found') {
        $message = "The requested user account profile could not be located.";
        $message_type = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USJ-R School Management System v1.01</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: Arial, sans-serif; }
        body { background-color: #f8f9fa; color: #333; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        .navbar { background-color: #1a252f; color: #ffffff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        .btn-logout { background-color: #e74c3c; color: white; padding: 6px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; }

        .dashboard-wrapper { display: flex; flex: 1; height: calc(100vh - 62px); }
        .sidebar { width: 260px; background-color: #f0f4f8; border-right: 1px solid #dcdfe4; padding-top: 20px; }
        .sidebar-menu { list-style: none; }
        .sidebar-menu li a { display: block; padding: 14px 25px; color: #1a252f; text-decoration: none; font-size: 18px; font-weight: 500; }
        .sidebar-menu li a:hover, .sidebar-menu li.active a { background-color: #e2e8f0; color: #1abc9c; font-weight: 600; }

        .two-column-layout { flex: 1; display: flex; gap: 24px; padding: 24px; overflow: hidden; }

        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        
        .panel-title { font-size: 22px; font-weight: bold; color: #000; margin-bottom: 25px; }
        .panel-title-sub { font-size: 20px; font-weight: bold; color: #000; margin-bottom: 25px; }
        
        .btn-red-back { background-color: #d9534f; color: white; padding: 8px 18px; border-radius: 4px; font-weight: bold; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; margin-bottom: 25px; font-size: 14px; border: none; }
        .btn-red-back:hover { background-color: #c9302c; }

        .data-table { width: 100%; border-collapse: collapse; background-color: #fff; margin-top: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .data-table th { background-color: #5cb85c; color: white; text-align: left; padding: 14px 15px; font-size: 15px; font-weight: bold; }
        .data-table td { padding: 14px 15px; border-bottom: 1px solid #ddd; font-size: 15px; color: #333; }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        .btn-grid-action { padding: 6px 14px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; color: white; display: inline-flex; align-items: center; gap: 5px; margin-right: 5px; border: none; cursor: pointer; }
        .btn-grid-settings { background-color: #5cb85c; }
        .btn-grid-settings:hover { background-color: #4cae4c; }
        .btn-grid-delete { background-color: #d9534f; }
        .btn-grid-delete:hover { background-color: #c9302c; }

        .table-footer { display: flex; justify-content: space-between; align-items: center; margin-top: 30px; font-size: 15px; }
        .pagination-btn { background-color: #ffffff; border: 1px solid #ddd; color: #333; padding: 8px 16px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .pagination-btn.next { background-color: #5cb85c; color: white; border-color: #4cae4c; }

        .upload-row { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .file-label-hint { font-size: 15px; color: #333; margin-left: 10px; }
        
        .btn-upload-submit { background-color: #5cb85c; color: white; padding: 8px 18px; border: 1px solid #4cae4c; border-radius: 4px; font-size: 14px; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 5px; }
        .btn-upload-submit:hover { background-color: #4cae4c; }

        .error-log-container { margin-top: 25px; border-top: 1px solid #eee; padding-top: 20px; }
        .error-log-header { font-size: 16px; color: #333; margin-bottom: 15px; font-weight: 500; }
        .error-log-line { font-size: 16px; color: #000; line-height: 1.6; }

        .button-menu-container { display: flex; justify-content: center; align-items: center; min-height: 60vh; }
        .button-workspace-card { background-color: #ffffff; border: 1px solid #dcdfe4; border-radius: 8px; padding: 35px; width: 100%; max-width: 400px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); text-align: center; }
        .workspace-heading { font-size: 18px; font-weight: 700; color: #1a252f; margin-bottom: 24px; text-transform: uppercase; letter-spacing: 0.5px; }
        .action-button-block { display: block; width: 100%; background-color: #5cb85c; color: #ffffff; text-decoration: none; font-size: 15px; font-weight: 600; padding: 14px 20px; border-radius: 4px; margin-bottom: 12px; border: 1px solid #4cae4c; }
        .action-button-block:hover { background-color: #4cae4c; }

        .alert-banner { padding: 12px 15px; border-radius: 4px; margin-bottom: 20px; font-size: 15px; max-width: 800px; }
        .alert-banner.success { background-color: #dff0d8; color: #3c763d; border: 1px solid #d6e9c6; }
        .alert-banner.error { background-color: #f2dede; color: #a94442; border: 1px solid #ebccd1; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
    </header>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="dashboard.php?view=schools">Schools</a></li>
                <li><a href="department.php">Departments</a></li>
                <li><a href="program.php">Programs</a></li>
                <li><a href="students.php">Students</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                    <li class="active"><a href="users.php">Users</a></li>
                <?php endif; ?>
            </ul>
        </aside>

        <main class="main-content">
            
            <?php if (!empty($message)): ?>
                <div class="alert-banner <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($action === 'manage'): ?>
                <div class="panel-title" style="font-size: 18px; font-weight: bold; margin-bottom: 15px;">User List</div>
                <a href="users.php" class="btn-red-back">❌ Back</a>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 15%;">User ID</th>
                            <th style="width: 30%;">User Name</th>
                            <th style="width: 30%;">User Type</th>
                            <th style="width: 25%;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($users_list) > 0): ?>
                            <?php foreach ($users_list as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                                   
                                    <td>
                                        <?php if ($_SESSION['role'] === 'Administrator'): ?>
                                            <a href="users.php?action=settings&id=<?php echo urlencode($row['id']); ?>" class="btn-grid-action btn-grid-settings">⚙ Settings</a>
                                            <a href="users.php?action=delete&id=<?php echo urlencode($row['id']); ?>" 
                                               class="btn-grid-action btn-grid-delete" 
                                               onclick="return confirm('Are you sure you want to permanently delete this user account profile?');">
                                               🗑 Delete
                                            </a>
                                        <?php else: ?>
                                            <span style="color: #aaa; font-style: italic;">No Permissions</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #aaa; padding: 25px;">No records located.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                
                <div class="table-footer">
                    <div>Total of: <?php echo count($users_list); ?> Users in the database</div>
                    <div>
                        <a href="#" class="pagination-btn" style="margin-right: 5px; color: #aaa; pointer-events: none;">Previous</a>
                        <a href="#" class="pagination-btn next">Next</a>
                    </div>
                </div>

            <?php elseif ($action === 'add' && $_SESSION['role'] === 'Administrator'): ?>
                <div class="panel-title-sub" style="font-size: 18px; font-weight: bold; margin-bottom: 20px;">Add Users From File</div>

                <form action="users.php?action=add" method="POST" enctype="multipart/form-data">
                    <div class="upload-row">
                        <input type="file" id="csv_file" name="csv_file" accept=".csv" required>
                        <span class="file-label-hint">Select a CSV file to upload</span>
                    </div>

                    <div class="upload-row" style="margin-top: 20px; gap: 10px;">
                        <button type="submit" name="upload_csv" class="btn-upload-submit">📤 Upload</button>
                        <a href="users.php" class="btn-red-back" style="margin-bottom:0; padding: 8px 18px;">❌ Exit</a>
                    </div>
                </form>

                <?php if (!empty($processing_errors) || (!empty($message) && $message_type === 'error')): ?>
                    <div class="error-log-container">
                        <div class="error-log-header">
                            <?php echo !empty($message) ? htmlspecialchars($message) : 'File processed with some errors. Please review the error messages.'; ?>
                        </div>
                        <?php foreach ($processing_errors as $err_line): ?>
                            <div class="error-log-line"><?php echo $err_line; ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            <?php elseif ($action === 'settings' && $edit_user && $_SESSION['role'] === 'Administrator'): ?>
                <div class="panel-title-sub" style="font-size: 18px; font-weight: bold; margin-bottom: 20px;">
                    Account Configuration Settings — Editing: <?php echo htmlspecialchars($edit_user['username']); ?>
                </div>

                <a href="users.php?action=manage" class="btn-red-back">🗙 Cancel Changes</a>

                <div style="display: flex; justify-content: center; margin-top: 10px;">
                    <div class="button-workspace-card" style="text-align: left; max-width: 480px; padding: 30px;">
                        <h1 class="workspace-heading" style="text-align: center; margin-bottom: 20px;">Modify Credentials</h1>
                        
                        <form action="users.php?action=settings&id=<?php echo urlencode($edit_user['id']); ?>" method="POST">
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-size: 14px; font-weight: bold; margin-bottom: 6px; color: #1a252f;">User ID (Immutable Identifier)</label>
                                <input type="text" value="<?php echo htmlspecialchars($edit_user['id']); ?>" disabled 
                                       style="width: 100%; padding: 10px; border: 1px solid #dcdfe4; border-radius: 4px; background-color: #f1f3f5; color: #6c757d; font-size: 14px;">
                            </div>

                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-size: 14px; font-weight: bold; margin-bottom: 6px; color: #1a252f;">Username</label>
                                <input type="text" name="new_username" value="<?php echo htmlspecialchars($edit_user['username']); ?>" required 
                                       style="width: 100%; padding: 10px; border: 1px solid #dcdfe4; border-radius: 4px; font-size: 14px; color: #333;">
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <label style="display: block; font-size: 14px; font-weight: bold; margin-bottom: 6px; color: #1a252f;">User Role Type</label>
                                <select name="new_role" style="width: 100%; padding: 10px; border: 1px solid #dcdfe4; border-radius: 4px; font-size: 14px; color: #333; background-color: #fff;">
                                    <option value="User" <?php echo ($edit_user['role'] !== 'Administrator') ? 'selected' : ''; ?>>User</option>
                                    <option value="Administrator" <?php echo ($edit_user['role'] === 'Administrator') ? 'selected' : ''; ?>>Administrator</option>
                                </select>
                            </div>

                            <div style="margin-bottom: 25px;">
                                <label style="display: block; font-size: 14px; font-weight: bold; margin-bottom: 6px; color: #1a252f;">Update Password (Leave blank to keep unchanged)</label>
                                <input type="password" name="new_password" placeholder="Enter new password token..." 
                                       style="width: 100%; padding: 10px; border: 1px solid #dcdfe4; border-radius: 4px; font-size: 14px; color: #333;">
                            </div>
                            
                            <button type="submit" name="update_settings" class="action-button-block" style="cursor: pointer; text-align: center; border: none;">
                                Save Settings Changes
                            </button>
                        </form>
                    </div>
                </div>

            <?php else: ?>
                <div class="button-menu-container">
                    <div class="button-workspace-card">
                        <h1 class="workspace-heading">User Operations</h1>
                        <a href="users.php?action=manage" class="action-button-block">Manage Users</a>
                        <a href="users.php?action=add" class="action-button-block">Add Users</a>
                    </div>
                </div>
            <?php endif; ?>

        </main>
    </div>

</body>
</html>