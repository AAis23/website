<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require_once 'db.php';

$action = isset($_GET['action']) ? trim($_GET['action']) : 'view';
$school_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$dept_id = isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0;

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['save_school'])) {
        $collid = isset($_POST['collid']) ? trim($_POST['collid']) : '';
        $collfullname = isset($_POST['collfullname']) ? trim($_POST['collfullname']) : '';
        $collshortname = isset($_POST['collshortname']) ? trim($_POST['collshortname']) : '';

        if (empty($collid) || empty($collfullname) || empty($collshortname)) {
            $message = "All form field parameters are required.";
            $message_type = "error";
        } elseif (!is_numeric($collid)) {
            $message = "School ID must be a numeric integer value.";
            $message_type = "error";
        } else {
            try {
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM colleges WHERE collid = ?");
                $check_stmt->execute([$collid]);
                if ($check_stmt->fetchColumn() > 0) {
                    $message = "Conflict: A school with ID registration entry '{$collid}' already exists.";
                    $message_type = "error";
                } else {
                    $insert_stmt = $pdo->prepare("INSERT INTO colleges (collid, collfullname, collshortname) VALUES (?, ?, ?)");
                    $insert_stmt->execute([$collid, $collfullname, $collshortname]);
                    header("Location: dashboard.php?view=schools");
                    exit;
                }
            } catch (\PDOException $e) {
                $message = "Database execution error: " . $e->getMessage();
                $message_type = "error";
            }
        }
    }

    if (isset($_POST['update_school'])) {
        $new_collid = isset($_POST['collid']) ? trim($_POST['collid']) : '';
        $collfullname = isset($_POST['collfullname']) ? trim($_POST['collfullname']) : '';
        $collshortname = isset($_POST['collshortname']) ? trim($_POST['collshortname']) : '';

        if (empty($new_collid) || empty($collfullname) || empty($collshortname)) {
            $message = "All text form inputs are required.";
            $message_type = "error";
        } elseif (!is_numeric($new_collid)) {
            $message = "School ID must be a numeric integer sequence value.";
            $message_type = "error";
        } else {
            try {
                $new_collid = intval($new_collid);
                
                if ($new_collid !== $school_id) {
                    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM colleges WHERE collid = ?");
                    $check_stmt->execute([$new_collid]);
                    if ($check_stmt->fetchColumn() > 0) {
                        $message = "Conflict: A school with registration ID '{$new_collid}' already occupies that slot.";
                        $message_type = "error";
                    }
                }

                if ($message_type !== 'error') {
                    $update_stmt = $pdo->prepare("UPDATE colleges SET collid = ?, collfullname = ?, collshortname = ? WHERE collid = ?");
                    $update_stmt->execute([$new_collid, $collfullname, $collshortname, $school_id]);
                    header("Location: dashboard.php?view=schools");
                    exit;
                }
            } catch (\PDOException $e) {
                $message = "Database record modification failure: " . $e->getMessage();
                $message_type = "error";
            }
        }
    }

    if (isset($_POST['confirm_delete_school'])) {
        try {
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE deptcollid = ?");
            $check_stmt->execute([$school_id]);
            if ($check_stmt->fetchColumn() > 0) {
                $message = "Cannot delete this school entry. Active departments are currently assigned to it.";
                $message_type = "error";
                $action = "delete_school"; 
            } else {
                $delete_stmt = $pdo->prepare("DELETE FROM colleges WHERE collid = ?");
                $delete_stmt->execute([$school_id]);
                header("Location: dashboard.php?view=schools");
                exit;
            }
        } catch (\PDOException $e) {
            $message = "Database operational failure: " . $e->getMessage();
            $message_type = "error";
        }
    }

    if (isset($_POST['confirm_delete_dept'])) {
        try {
            $check_programs = $pdo->prepare("SELECT COUNT(*) FROM programs WHERE progcolldeptid = ?");
            $check_programs->execute([$dept_id]);
            $check_students = $pdo->prepare("SELECT COUNT(*) FROM students WHERE studcolldeptid = ?");
            $check_students->execute([$dept_id]);

            if ($check_programs->fetchColumn() > 0 || $check_students->fetchColumn() > 0) {
                $message = "Cannot remove this department entry. It has active academic programs or enrolled students assigned.";
                $message_type = "error";
                $action = "delete_dept"; 
            } else {
                $delete_stmt = $pdo->prepare("DELETE FROM departments WHERE deptid = ?");
                $delete_stmt->execute([$dept_id]);
                header("Location: school.php?id=" . $school_id);
                exit;
            }
        } catch (\PDOException $e) {
            $message = "Database operational failure: " . $e->getMessage();
            $message_type = "error";
        }
    }
}

$school = null;
$departments = [];
$total_departments = 0;
$total_pages = 1;
$current_page = 1;

if ($action === 'delete_dept' && $dept_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE deptid = ?");
    $stmt->execute([$dept_id]);
    $department = $stmt->fetch();
    if (!$department) { header("Location: dashboard.php?view=schools"); exit; }
    $school_id = $department['deptcollid']; 
}

if ($school_id > 0) {
    $school_stmt = $pdo->prepare("SELECT * FROM colleges WHERE collid = ?");
    $school_stmt->execute([$school_id]);
    $school = $school_stmt->fetch();

    if (!$school && $action !== 'create') {
        header("Location: dashboard.php?view=schools");
        exit;
    }

    if ($action === 'view') {
        $limit = 6; // Set to 6 per page
        $current_page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
        $offset = ($current_page - 1) * $limit;

        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE deptcollid = ?");
        $count_stmt->execute([$school_id]);
        $total_departments = $count_stmt->fetchColumn();
        $total_pages = ceil($total_departments / $limit);

        $dept_stmt = $pdo->prepare("SELECT deptid, deptfullname, deptshortname FROM departments WHERE deptcollid = ? LIMIT ? OFFSET ?");
        $dept_stmt->bindValue(1, $school_id, PDO::PARAM_INT);
        $dept_stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $dept_stmt->bindValue(3, $offset, PDO::PARAM_INT);
        $dept_stmt->execute();
        $departments = $dept_stmt->fetchAll();
    }
} elseif ($action !== 'create') {
    header("Location: dashboard.php?view=schools");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Management Studio</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background-color: #f8f9fa; color: #333; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }
        
        .navbar { background-color: #1a252f; color: #ffffff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        .btn-logout { background-color: #e74c3c; color: white; padding: 6px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; }

        .dashboard-wrapper { display: flex; flex: 1; height: calc(100vh - 62px); }
        .sidebar { width: 260px; background-color: #f0f4f8; border-right: 1px solid #dcdfe4; padding-top: 20px; }
        .sidebar-menu { list-style: none; }
        .sidebar-menu li a { display: block; padding: 14px 25px; color: #1a252f; text-decoration: none; font-size: 18px; font-weight: 500; }
        .sidebar-menu li a:hover, .sidebar-menu li.active a { background-color: #e2e8f0; color: #1abc9c; font-weight: 600; }

        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .module-header { font-size: 22px; font-weight: bold; color: #000; margin-bottom: 25px; }
        .warn-notice { font-size: 16px; color: #000; margin-bottom: 20px; }

        /* Form Components */
        .form-row { display: flex; align-items: center; margin-bottom: 20px; max-width: 900px; }
        .form-label { width: 220px; font-size: 18px; color: #000; font-weight: 500; }
        .form-control { flex: 1; padding: 10px 14px; font-size: 16px; border: 1px solid #ccc; border-radius: 6px; outline: none; }
        .form-actions-bar { display: flex; gap: 12px; margin-top: 30px; padding-left: 220px; }

        /* Tables & Action Controls */
        .btn-green { background-color: #4caf50; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; text-decoration: none; display: inline-block; margin-bottom: 20px; font-size: 14px; border: none; }
        .data-table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 15px; }
        .data-table th { background-color: #4caf50; color: white; text-align: left; padding: 12px 15px; font-size: 14px; }
        .data-table td { padding: 12px 15px; border-bottom: 1px solid #e0e0e0; font-size: 14px; color: #000; }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        .btn-action { padding: 5px 10px; border-radius: 3px; text-decoration: none; font-weight: bold; font-size: 12px; color: white; display: inline-block; margin-right: 5px; }
        .btn-update { background-color: #4caf50; }
        .btn-delete { background-color: #e74c3c; }
        
        .btn-submit { background-color: #e0e0e0; color: #000; border: 1px solid #adadad; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn-reset { background-color: #bfbfbf; color: #000; border: 1px solid #9c9c9c; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn-exit, .btn-confirm-red, .btn-cancel-green { border: none; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; font-weight: bold; text-decoration: none; display: inline-block; text-align: center; }
        .btn-exit { background-color: #e74c3c; color: #fff; }
        .btn-confirm-red { background-color: #e74c3c; color: #fff; padding: 10px 20px; font-size: 15px; }
        .btn-cancel-green { background-color: #4caf50; color: #fff; padding: 10px 20px; font-size: 15px; }

        .confirmation-table { width: 100%; max-width: 650px; border-collapse: collapse; background-color: #fff; margin-bottom: 25px; }
        .confirmation-table td { border: 1px solid #666; padding: 10px 15px; font-size: 15px; color: #000; }
        .confirmation-table td.label-cell { width: 30%; font-weight: bold; }
        .prompt-text { font-size: 16px; font-weight: 500; color: #000; margin-bottom: 15px; }
        .relationship-subtext { font-size: 14px; color: #333; line-height: 1.5; margin-bottom: 25px; }

        .alert-banner { padding: 12px 15px; border-radius: 4px; margin-bottom: 20px; font-size: 14px; font-weight: bold; max-width: 900px; }
        .alert-banner.error { background-color: #fde8e8; color: #e74c3c; border: 1px solid #f8b4b4; }
        
        .pagination-container { display: flex; justify-content: space-between; align-items: center; margin-top: 20px; font-size: 14px; color: #555; }
        .pagination-buttons { display: flex; gap: 5px; }
        .page-link { padding: 6px 12px; border: 1px solid #ccc; background-color: white; color: #333; text-decoration: none; border-radius: 4px; }
        .page-link.active { background-color: #4caf50; color: white; border-color: #4caf50; font-weight: bold; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
    </header>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Home</a></li>
                <li class="active"><a href="dashboard.php?view=schools">Schools</a></li>
                <li><a href="department.php">Departments</a></li>
                <li><a href="program.php">Programs</a></li>
                <li><a href="students.php">Students</a></li>
                <li><a href="users.php">Users</a></li>
            </ul>
        </aside>

        <main class="main-content">
            
            <?php if (!empty($message)): ?>
                <div class="alert-banner <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($action === 'create'): ?>
                <div class="module-header">School Create</div>
                <form action="school.php?action=create" method="POST">
                    <div class="form-row">
                        <label class="form-label" for="collid">School ID:</label>
                        <input class="form-control" type="text" id="collid" name="collid" value="<?php echo isset($_POST['collid']) ? htmlspecialchars($_POST['collid']) : ''; ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="collfullname">School Full Name:</label>
                        <input class="form-control" type="text" id="collfullname" name="collfullname" value="<?php echo isset($_POST['collfullname']) ? htmlspecialchars($_POST['collfullname']) : ''; ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="collshortname">School Short Name:</label>
                        <input class="form-control" type="text" id="collshortname" name="collshortname" value="<?php echo isset($_POST['collshortname']) ? htmlspecialchars($_POST['collshortname']) : ''; ?>" required autocomplete="off">
                    </div>
                    <div class="form-actions-bar">
                        <button class="btn-submit" type="submit" name="save_school">Save New School Entry</button>
                        <button class="btn-reset" type="reset">Reset Form</button>
                        <a class="btn-exit" href="dashboard.php?view=schools">Exit</a>
                    </div>
                </form>

            <?php elseif ($action === 'update_school'): ?>
                <div class="module-header">School Update Profile</div>
                <form action="school.php?action=update_school&id=<?php echo $school_id; ?>" method="POST">
                    <div class="form-row">
                        <label class="form-label" for="collid">School ID:</label>
                        <input class="form-control" type="text" id="collid" name="collid" value="<?php echo htmlspecialchars($school['collid']); ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="collfullname">School Full Name:</label>
                        <input class="form-control" type="text" id="collfullname" name="collfullname" value="<?php echo htmlspecialchars($school['collfullname']); ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="collshortname">School Short Name:</label>
                        <input class="form-control" type="text" id="collshortname" name="collshortname" value="<?php echo htmlspecialchars($school['collshortname']); ?>" required autocomplete="off">
                    </div>
                    <div class="form-actions-bar">
                        <button class="btn-submit" type="submit" name="update_school">Save Changes</button>
                        <a class="btn-exit" href="dashboard.php?view=schools">Exit / Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'delete_school'): ?>
                <div class="warn-notice">You are about to delete the following school entry:</div>
                <table class="confirmation-table">
                    <tr><td class="label-cell">School ID:</td><td><?php echo htmlspecialchars($school['collid']); ?></td></tr>
                    <tr><td class="label-cell">School Full Name:</td><td><?php echo htmlspecialchars($school['collfullname']); ?></td></tr>
                    <tr><td class="label-cell">School Short Name:</td><td><?php echo htmlspecialchars($school['collshortname']); ?></td></tr>
                </table>
                <div class="prompt-text">Are you sure you want to delete this school entry?</div>
                <div class="relationship-subtext">This entry is part of a high-level relationship in the database.<br>Deleting this entry may affect related data tracking profiles.</div>
                <form action="school.php?action=delete_school&id=<?php echo $school_id; ?>" method="POST">
                    <div class="action-button-group">
                        <button type="submit" name="confirm_delete_school" class="btn-confirm-red">Yes, Delete Entry</button>
                        <a href="dashboard.php?view=schools" class="btn-cancel-green">No, Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'delete_dept'): ?>
                <div class="warn-notice">You are about to delete the following department entry:</div>
                <table class="confirmation-table">
                    <tr><td class="label-cell">Department ID:</td><td><?php echo htmlspecialchars($department['deptid']); ?></td></tr>
                    <tr><td class="label-cell">Department Full Name:</td><td><?php echo htmlspecialchars($department['deptfullname']); ?></td></tr>
                    <tr><td class="label-cell">Department Short Name:</td><td><?php echo htmlspecialchars(!empty($department['deptshortname']) ? $department['deptshortname'] : '—'); ?></td></tr>
                </table>
                <div class="prompt-text">Are you sure you want to delete this department entry?</div>
                <div class="relationship-subtext">This entry is part of a high-level relationship in the database.<br>Deleting this entry may affect related data.</div>
                <form action="school.php?action=delete_dept&id=<?php echo $school_id; ?>&dept_id=<?php echo $dept_id; ?>" method="POST">
                    <div class="action-button-group">
                        <button type="submit" name="confirm_delete_dept" class="btn-confirm-red">Yes, Delete Entry</button>
                        <a href="school.php?id=<?php echo $school_id; ?>" class="btn-cancel-green">No, Cancel</a>
                    </div>
                </form>

            <?php else: ?>
                <div class="module-header">
                    Registered Departments: <?php echo htmlspecialchars($school['collfullname']); ?> (<?php echo htmlspecialchars($school['collshortname']); ?>)
                </div>

                <a href="#create-dept" class="btn-green">⊕ Create Department Entry</a>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 15%;">Department ID</th>
                            <th style="width: 50%;">Department Full Name</th>
                            <th style="width: 20%;">Department Short Name</th>
                            <th style="width: 15%;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($departments) > 0): ?>
                            <?php foreach ($departments as $dept): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($dept['deptid']); ?></td>
                                    <td><?php echo htmlspecialchars($dept['deptfullname']); ?></td>
                                    <td><?php echo htmlspecialchars(!empty($dept['deptshortname']) ? $dept['deptshortname'] : '—'); ?></td>
                                    <td>
                                        <a href="#update" class="btn-action btn-update">Update</a>
                                        <a href="school.php?action=delete_dept&dept_id=<?php echo $dept['deptid']; ?>" class="btn-action btn-delete">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #7f8c8d; padding: 20px;">No departments registered under this school asset block yet.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="pagination-container">
                    <div>Total of: <strong><?php echo $total_departments; ?></strong> registered departments inside this school tracking selection.</div>
                    
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination-buttons">
                            <?php if ($current_page > 1): ?>
                                <a href="school.php?id=<?php echo $school_id; ?>&p=<?php echo $current_page - 1; ?>" class="page-link">« Prev</a>
                            <?php endif; ?>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="school.php?id=<?php echo $school_id; ?>&p=<?php echo $i; ?>" class="page-link <?php echo ($i === $current_page) ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>

                            <?php if ($current_page < $total_pages): ?>
                                <a href="school.php?id=<?php echo $school_id; ?>&p=<?php echo $current_page + 1; ?>" class="page-link">Next »</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

</body>
</html>