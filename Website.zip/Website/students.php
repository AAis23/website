<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
require_once 'db.php';


$action = isset($_GET['action']) ? trim($_GET['action']) : 'view';
$stud_id = isset($_GET['id']) ? trim($_GET['id']) : '';


$selected_school_id = isset($_POST['school_id']) ? intval($_POST['school_id']) : (isset($_GET['school_id']) ? intval($_GET['school_id']) : 0);
$selected_dept_id   = isset($_POST['dept_id']) ? intval($_POST['dept_id']) : (isset($_GET['dept_id']) ? intval($_GET['dept_id']) : 0);
$selected_prog_id   = isset($_POST['prog_id']) ? trim($_POST['prog_id']) : (isset($_GET['prog_id']) ? trim($_GET['prog_id']) : '');

$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

$message = '';
$message_type = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['save_student'])) {
        $studid = trim($_POST['studid']);
        $studfirstname = trim($_POST['studfirstname']);
        $studlastname = trim($_POST['studlastname']);
        $studmidname = trim($_POST['studmidname']);
        $studyear = intval($_POST['studyear']);

        if (empty($studid) || empty($studfirstname) || empty($studlastname) || $studyear <= 0 || empty($selected_prog_id)) {
            $message = "All text fields and numeric selections are required.";
            $message_type = "error";
        } else {
            try {
                $check = $pdo->prepare("SELECT COUNT(*) FROM students WHERE studid = ?");
                $check->execute([$studid]);
                if ($check->fetchColumn() > 0) {
                    throw new Exception("Conflict: Student ID No. '{$studid}' already exists.");
                }

                $stmt = $pdo->prepare("INSERT INTO students (studid, studfirstname, studlastname, studmidname, studprogid, studyear, studcollid, studcolldeptid) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$studid, $studfirstname, $studlastname, $studmidname, $selected_prog_id, $studyear, $selected_school_id, $selected_dept_id]);
                
                header("Location: students.php?school_id={$selected_school_id}&dept_id={$selected_dept_id}&prog_id=" . urlencode($selected_prog_id));
                exit;
            } catch (\Exception $e) {
                $message = $e->getMessage();
                $message_type = "error";
            }
        }
    }

    if (isset($_POST['update_student'])) {
        $old_studid = trim($_POST['old_studid']);
        $new_studid = trim($_POST['studid']);
        $studfirstname = trim($_POST['studfirstname']);
        $studlastname = trim($_POST['studlastname']);
        $studmidname = trim($_POST['studmidname']);
        $studyear = intval($_POST['studyear']);

        if (empty($new_studid) || empty($studfirstname) || empty($studlastname) || $studyear <= 0) {
            $message = "All data validation fields are required.";
            $message_type = "error";
            $action = 'update';
            $stud_id = $old_studid;
        } else {
            try {
                if ($old_studid !== $new_studid) {
                    $check = $pdo->prepare("SELECT COUNT(*) FROM students WHERE studid = ?");
                    $check->execute([$new_studid]);
                    if ($check->fetchColumn() > 0) {
                        throw new Exception("Conflict: Student ID No. already exists.");
                    }
                }

                $stmt = $pdo->prepare("UPDATE students SET studid = ?, studfirstname = ?, studlastname = ?, studmidname = ?, studyear = ? WHERE studid = ?");
                $stmt->execute([$new_studid, $studfirstname, $studlastname, $studmidname, $studyear, $old_studid]);
                
                header("Location: students.php?school_id={$selected_school_id}&dept_id={$selected_dept_id}&prog_id=" . urlencode($selected_prog_id));
                exit;
            } catch (\Exception $e) {
                $message = $e->getMessage();
                $message_type = "error";
                $action = 'update';
                $stud_id = $old_studid;
            }
        }
    }

    if (isset($_POST['confirm_delete_student'])) {
        try {
            $stmt = $pdo->prepare("DELETE FROM students WHERE studid = ?");
            $stmt->execute([$stud_id]);
            header("Location: students.php?school_id={$selected_school_id}&dept_id={$selected_dept_id}&prog_id=" . urlencode($selected_prog_id));
            exit;
        } catch (\PDOException $e) {
            $message = "Delete Error: " . $e->getMessage();
            $message_type = "error";
        }
    }
}

$schools = [];
$departments = [];
$programs = [];
$students = [];
$edit_student_data = null;

try {
    $schools = $pdo->query("SELECT collid, collfullname FROM colleges ORDER BY collfullname ASC")->fetchAll();

    if ($selected_school_id > 0) {
        $stmt = $pdo->prepare("SELECT deptid, deptfullname FROM departments WHERE deptcollid = ? ORDER BY deptfullname ASC");
        $stmt->execute([$selected_school_id]);
        $departments = $stmt->fetchAll();
    }

    if ($selected_school_id > 0 && $selected_dept_id > 0) {
        $stmt = $pdo->prepare("SELECT progid, progfullname FROM programs WHERE progcollid = ? AND progcolldeptid = ? ORDER BY progfullname ASC");
        $stmt->execute([$selected_school_id, $selected_dept_id]);
        $programs = $stmt->fetchAll();
    }
} catch (\PDOException $e) {
    die("Database initial selection contextual error: " . $e->getMessage());
}

if (($action === 'update' || $action === 'delete') && !empty($stud_id)) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE studid = ?");
    $stmt->execute([$stud_id]);
    $edit_student_data = $stmt->fetch();
    if ($edit_student_data) {
        $selected_school_id = intval($edit_student_data['studcollid']);
        $selected_dept_id   = intval($edit_student_data['studcolldeptid']);
        $selected_prog_id   = $edit_student_data['studprogid'];
    }
}

$show_grid = ($selected_school_id > 0 && $selected_dept_id > 0 && !empty($selected_prog_id));
$total_students = 0;
$total_pages = 1;
$current_page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$limit = 5;
$offset = ($current_page - 1) * $limit;

if ($show_grid) {
    try {
        $count_query = "SELECT COUNT(*) FROM students WHERE studcollid = ? AND studcolldeptid = ? AND studprogid = ?";
        $data_query  = "SELECT * FROM students WHERE studcollid = ? AND studcolldeptid = ? AND studprogid = ?";
        $params = [$selected_school_id, $selected_dept_id, $selected_prog_id];

        if (!empty($search_query)) {
            $count_query .= " AND (studid LIKE ? OR studfirstname LIKE ? OR studlastname LIKE ?)";
            $data_query  .= " AND (studid LIKE ? OR studfirstname LIKE ? OR studlastname LIKE ?)";
            $search_wildcard = "%{$search_query}%";
            $params[] = $search_wildcard;
            $params[] = $search_wildcard;
            $params[] = $search_wildcard;
        }

        $data_query .= " ORDER BY studlastname ASC, studfirstname ASC LIMIT " . intval($limit) . " OFFSET " . intval($offset);

        $count_stmt = $pdo->prepare($count_query);
        $count_stmt->execute($params);
        $total_students = $count_stmt->fetchColumn();
        $total_pages = ceil($total_students / $limit);

        $data_stmt = $pdo->prepare($data_query);
        $data_stmt->execute($params);
        $students = $data_stmt->fetchAll();
    } catch (\PDOException $e) {
        die("Roster calculation syntax failure: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Roster Workspace</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f3f7fa; color: #333; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }

        .navbar { background-color: #1a252f; color: #ffffff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        .btn-logout { background-color: #e74c3c; color: white; padding: 6px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; }

        .workspace-container { display: flex; flex: 1; height: calc(100vh - 55px); overflow: hidden; }
        
        .dashboard-wrapper { display: flex; flex: 1; height: calc(100vh - 62px); }
        .sidebar { width: 260px; background-color: #f0f4f8; border-right: 1px solid #dcdfe4; padding-top: 20px; }
        .sidebar-menu { list-style: none; }
        .sidebar-menu li a { display: block; padding: 14px 25px; color: #1a252f; text-decoration: none; font-size: 18px; font-weight: 500; }
        .sidebar-menu li a:hover, .sidebar-menu li.active a { background-color: #e2e8f0; color: #1abc9c; font-weight: 600; }

        .two-column-layout { flex: 1; display: flex; gap: 24px; padding: 24px; overflow: hidden; }
        
        .left-column { width: 340px; display: flex; flex-direction: column; gap: 20px; overflow-y: auto; height: 100%; padding-right: 4px; }
        .right-column { flex: 1; display: flex; flex-direction: column; overflow-y: auto; height: 100%; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }

        .panel-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 18px; box-shadow: 0 1px 3px rgba(0,0,0,0.02); }
        .panel-title { font-size: 15px; font-weight: 700; color: #1e293b; margin-bottom: 14px; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; text-transform: uppercase; letter-spacing: 0.3px; }
        
        .form-group { margin-bottom: 12px; }
        .form-label { display: block; font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 5px; text-transform: uppercase; }
        .form-control { width: 100%; padding: 9px 12px; font-size: 14px; border: 1px solid #cbd5e1; border-radius: 6px; outline: none; background-color: #fff; color: #333; }
        .form-control:focus { border-color: #3b82f6; box-shadow: 0 0 0 2px rgba(59,130,246,0.1); }
        .form-control:disabled { background-color: #f8fafc; color: #94a3b8; cursor: not-allowed; }

        .btn-green-submit { width: 100%; background-color: #22c55e; color: white; border: none; padding: 10px; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 8px; display: block; text-align: center; text-decoration: none; }
        .btn-green-submit:hover { background-color: #16a34a; }
        .btn-cancel-link { width: 100%; background-color: #94a3b8; color: white; border: none; padding: 10px; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 6px; text-align: center; text-decoration: none; display: block; }
        .btn-cancel-link:hover { background-color: #64748b; }

        .search-container { display: flex; gap: 8px; margin-bottom: 16px; }
        .search-control { flex: 1; padding: 8px 12px; font-size: 14px; border: 1px solid #cbd5e1; border-radius: 6px; outline: none; }
        .btn-search { background-color: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px; }
        .btn-search:hover { background-color: #2563eb; }
        .btn-clear { background-color: #e2e8f0; color: #475569; border: none; padding: 8px 14px; border-radius: 6px; font-weight: 500; text-decoration: none; font-size: 14px; display: inline-block; line-height: 1.5; }
        .btn-clear:hover { background-color: #cbd5e1; }

        .grid-header-title { font-size: 18px; font-weight: 700; color: #0f172a; margin-bottom: 4px; }
        .grid-sub-breadcrumbs { font-size: 13px; color: #64748b; margin-bottom: 16px; font-weight: 500; }
        
        .data-table { width: 100%; border-collapse: collapse; background-color: #fff; margin-bottom: 15px; text-align: left; }
        .data-table th { background-color: #22c55e; color: white; padding: 12px 14px; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.2px; }
        .data-table td { padding: 12px 14px; border-bottom: 1px solid #f1f5f9; font-size: 14px; color: #334155; vertical-align: middle; }
        .data-table tr:nth-child(even) td { background-color: #f8fafc; }
        
        .btn-grid-action { padding: 4px 10px; border-radius: 4px; text-decoration: none; font-weight: 600; font-size: 12px; color: white; display: inline-block; margin-right: 4px; }
        .btn-grid-update { background-color: #22c55e; }
        .btn-grid-update:hover { background-color: #16a34a; }
        .btn-grid-delete { background-color: #ef4444; }
        .btn-grid-delete:hover { background-color: #dc2626; }

        .alert-banner { padding: 10px 14px; border-radius: 6px; margin-bottom: 16px; font-size: 13.5px; font-weight: 600; }
        .alert-banner.error { background-color: #fee2e2; color: #ef4444; border: 1px solid #fca5a5; }

        .confirmation-box { background-color: #fff; border: 1px solid #fca5a5; padding: 20px; border-radius: 8px; margin-bottom: 15px; }
        .confirmation-table { margin: 12px 0; font-size: 14px; width: 100%; max-width: 400px; }
        .confirmation-table td { padding: 4px 0; }
        .confirmation-table td.lbl { font-weight: bold; width: 120px; color: #64748b; }
        
        .pagination-container { display: flex; justify-content: space-between; align-items: center; margin-top: 20px; font-size: 14px; color: #555; }
        .pagination-buttons { display: flex; gap: 5px; }
        .page-link { padding: 6px 12px; border: 1px solid #ccc; background-color: white; color: #333; text-decoration: none; border-radius: 4px; }
        .page-link.active { background-color: #4caf50; color: white; border-color: #4caf50; font-weight: bold; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
    </header>

    <div class="workspace-container">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="dashboard.php?view=schools">Schools</a></li>
                <li><a href="department.php">Departments</a></li>
                <li><a href="program.php">Programs</a></li>
                <li class="active"><a href="students.php">Students</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                <li><a href="users.php">Users</a></li>
               <?php endif; ?>
            </ul>
        </aside>

        <div class="two-column-layout">
            
            <div class="left-column">
                
                <div class="panel-card">
                    <div class="panel-title">Filter Selection</div>
                    
                    <form action="students.php" method="POST" id="schoolFilterForm" style="margin-bottom: 12px;">
                        <div class="form-group">
                            <label class="form-label">School</label>
                            <select name="school_id" class="form-control" onchange="document.getElementById('schoolFilterForm').submit();">
                                <option value="0" disabled <?php echo ($selected_school_id === 0) ? 'selected' : ''; ?>>-- Select School --</option>
                                <?php foreach ($schools as $sch): ?>
                                    <option value="<?php echo $sch['collid']; ?>" <?php echo ($selected_school_id === (int)$sch['collid']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($sch['collfullname']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>

                    <form action="students.php" method="POST" id="deptFilterForm" style="margin-bottom: 12px;">
                        <input type="hidden" name="school_id" value="<?php echo $selected_school_id; ?>">
                        <div class="form-group">
                            <label class="form-label">Department</label>
                            <select name="dept_id" class="form-control" <?php echo ($selected_school_id === 0) ? 'disabled' : ''; ?> onchange="document.getElementById('deptFilterForm').submit();">
                                <option value="0" disabled <?php echo ($selected_dept_id === 0) ? 'selected' : ''; ?>>-- Select Department --</option>
                                <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo $dept['deptid']; ?>" <?php echo ($selected_dept_id === (int)$dept['deptid']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($dept['deptfullname']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>

                    <form action="students.php" method="POST" id="progFilterForm">
                        <input type="hidden" name="school_id" value="<?php echo $selected_school_id; ?>">
                        <input type="hidden" name="dept_id" value="<?php echo $selected_dept_id; ?>">
                        <div class="form-group">
                            <label class="form-label">Program</label>
                            <select name="prog_id" class="form-control" <?php echo ($selected_dept_id === 0) ? 'disabled' : ''; ?> onchange="document.getElementById('progFilterForm').submit();">
                                <option value="" disabled <?php echo empty($selected_prog_id) ? 'selected' : ''; ?>>-- Select Program --</option>
                                <?php foreach ($programs as $prog): ?>
                                    <option value="<?php echo $prog['progid']; ?>" <?php echo ($selected_prog_id === (string)$prog['progid']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($prog['progfullname']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </form>
                </div>

                <?php if ($show_grid): ?>
                    
                    <?php if ($action === 'update' && $edit_student_data): ?>
                        <div class="panel-card">
                            <div class="panel-title">Update Student</div>
                            <form action="students.php?action=update&id=<?php echo urlencode($stud_id); ?>&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" method="POST">
                                <input type="hidden" name="old_studid" value="<?php echo htmlspecialchars($edit_student_data['studid']); ?>">
                                
                                <div class="form-group">
                                    <label class="form-label">Student ID No.</label>
                                    <input class="form-control" type="text" name="studid" value="<?php echo htmlspecialchars($edit_student_data['studid']); ?>" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">First Name</label>
                                    <input class="form-control" type="text" name="studfirstname" value="<?php echo htmlspecialchars($edit_student_data['studfirstname']); ?>" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Last Name</label>
                                    <input class="form-control" type="text" name="studlastname" value="<?php echo htmlspecialchars($edit_student_data['studlastname']); ?>" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Middle Name</label>
                                    <input class="form-control" type="text" name="studmidname" value="<?php echo htmlspecialchars($edit_student_data['studmidname']); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Year Level</label>
                                    <input class="form-control" type="number" name="studyear" min="1" max="6" value="<?php echo htmlspecialchars($edit_student_data['studyear']); ?>" required>
                                </div>

                                <button type="submit" name="update_student" class="btn-green-submit">Update Student</button>
                                <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" class="btn-cancel-link">Cancel</a>
                            </form>
                        </div>
                    
                    <?php else: ?>
                        <div class="panel-card">
                            <div class="panel-title">Add Student</div>
                            <form action="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" method="POST">
                                
                                <div class="form-group">
                                    <label class="form-label">Student ID No.</label>
                                    <input class="form-control" type="text" name="studid" placeholder="e.g. 20260001" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">First Name</label>
                                    <input class="form-control" type="text" name="studfirstname" placeholder="e.g. John" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Last Name</label>
                                    <input class="form-control" type="text" name="studlastname" placeholder="e.g. Doe" required autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Middle Name</label>
                                    <input class="form-control" type="text" name="studmidname" placeholder="e.g. Smith" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Year Level</label>
                                    <input class="form-control" type="number" name="studyear" min="1" max="6" placeholder="e.g. 1" required>
                                </div>

                                <button type="submit" name="save_student" class="btn-green-submit">Save Student</button>
                            </form>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>
            </div>

            <div class="right-column">
                
                <?php if (!empty($message)): ?>
                    <div class="alert-banner error"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>

                <?php if ($show_grid): ?>
                    
                    <?php if ($action === 'delete' && $edit_student_data): ?>
                        <div class="confirmation-box">
                            <div class="grid-header-title" style="color:#ef4444;">Confirm Deletion</div>
                            <p style="font-size:14px; margin-top:4px;">Are you sure you want to permanently remove this student profile record?</p>
                            <table class="confirmation-table">
                                <tr><td class="lbl">ID Number:</td><td><strong><?php echo htmlspecialchars($edit_student_data['studid']); ?></strong></td></tr>
                                <tr><td class="lbl">Student Name:</td><td><?php echo htmlspecialchars($edit_student_data['studlastname'] . ', ' . $edit_student_data['studfirstname']); ?></td></tr>
                            </table>
                            <form action="students.php?action=delete&id=<?php echo urlencode($stud_id); ?>&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" method="POST" style="display:flex; gap:8px; margin-top:10px;">
                                <button type="submit" name="confirm_delete_student" class="btn-grid-action btn-grid-delete" style="padding: 8px 16px;">Yes, Delete Record</button>
                                <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" class="btn-clear" style="padding: 6px 14px; font-size:12px;">Cancel</a>
                            </form>
                        </div>
                    <?php endif; ?>

                    <div class="grid-header-title">Student Directory</div>
                    <div class="grid-sub-breadcrumbs">
                        Selection Context Track: School ID <?php echo $selected_school_id; ?> &gt; Dept ID <?php echo $selected_dept_id; ?> &gt; Program Code "<?php echo htmlspecialchars($selected_prog_id); ?>"
                    </div>

                    <form action="students.php" method="GET" class="search-container">
                        <input type="hidden" name="school_id" value="<?php echo $selected_school_id; ?>">
                        <input type="hidden" name="dept_id" value="<?php echo $selected_dept_id; ?>">
                        <input type="hidden" name="prog_id" value="<?php echo htmlspecialchars($selected_prog_id); ?>">
                        
                        <input type="text" name="search" class="search-control" placeholder="Search by ID No, First Name, or Last Name..." value="<?php echo htmlspecialchars($search_query); ?>" autocomplete="off">
                        <button type="submit" class="btn-search">Search</button>
                        <?php if (!empty($search_query)): ?>
                            <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" class="btn-clear">Clear</a>
                        <?php endif; ?>
                    </form>

                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 20%;">ID Number</th>
                                <th style="width: 25%;">Last Name</th>
                                <th style="width: 25%;">First Name</th>
                                <th style="width: 15%;">Middle Name</th>
                                <th style="width: 5%;">Year</th>
                                <th style="width: 10%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($students) > 0): ?>
                                <?php foreach ($students as $st): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($st['studid']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($st['studlastname']); ?></td>
                                        <td><?php echo htmlspecialchars($st['studfirstname']); ?></td>
                                        <td><?php echo htmlspecialchars(!empty($st['studmidname']) ? $st['studmidname'] : '—'); ?></td>
                                        <td><?php echo htmlspecialchars($st['studyear']); ?></td>
                                        <td>
                                            <a href="students.php?action=update&id=<?php echo urlencode($st['studid']); ?>&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" class="btn-grid-action btn-grid-update">Update</a>
                                            <a href="students.php?action=delete&id=<?php echo urlencode($st['studid']); ?>&school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>" class="btn-grid-action btn-grid-delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align: center; color: #94a3b8; padding: 30px;">No registered student records located for current filtering search criteria parameters.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="pagination-bar">
                        <div>Total Students: <strong><?php echo $total_students; ?></strong> match records found.</div>
                        <?php if ($total_pages > 1): ?>
                            <div class="pagination-links">
                                <?php if ($current_page > 1): ?>
                                    <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>&search=<?php echo urlencode($search_query); ?>&p=<?php echo $current_page - 1; ?>" class="page-item">« Prev</a>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>&search=<?php echo urlencode($search_query); ?>&p=<?php echo $i; ?>" class="page-item <?php echo ($i === $current_page) ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($current_page < $total_pages): ?>
                                    <a href="students.php?school_id=<?php echo $selected_school_id; ?>&dept_id=<?php echo $selected_dept_id; ?>&prog_id=<?php echo urlencode($selected_prog_id); ?>&search=<?php echo urlencode($search_query); ?>&p=<?php echo $current_page + 1; ?>" class="page-item">Next »</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                <?php else: ?>
                    <div style="text-align: center; margin: auto 0; padding: 40px; color: #94a3b8;">
                        <svg style="width: 48px; height: 48px; margin-bottom: 12px; color: #cbd5e1;" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                        </svg>
                        <p style="font-size: 15px; font-weight: 500;">Please choose a valid School, Department, and explicit Program tracker configuration mapping options via the left selector deck panels to populate the tracking registry data matrix.</p>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>

</body>
</html>