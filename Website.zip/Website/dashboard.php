<?php
session_start();

// Redirect back to login if no active session is detected
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// Include database configuration file
require_once 'db.php';

// Handle logout operation
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Fetch schools dynamically if the schools list view is active
$schools = [];
$totalColleges = 0;
try {
    if (isset($_GET['view']) && $_GET['view'] === 'schools') {
        $school_stmt = $pdo->query("SELECT collid, collfullname, collshortname FROM colleges ORDER BY collid ASC");
        $schools = $school_stmt->fetchAll();
        $totalColleges = count($schools);
    }
} catch (\PDOException $e) {
    die("Database communication error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>USJ-R School Management System v1.01 - Dashboard</title>
    <style>
        * { 
            margin: 0; 
            padding: 0; 
            box-sizing: border-box; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        }
        
        body { 
            background-color: #f8f9fa; 
            color: #333;
            height: 100vh;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        /* Header Navbar */
        .navbar {
            background-color: #1a252f; 
            color: #ffffff; 
            padding: 15px 30px;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            z-index: 10;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        
        .user-profile { display: flex; align-items: center; gap: 20px; }
        .user-info { font-size: 14px; text-align: right; }
        .user-info span { display: block; font-size: 11px; color: #bdc3c7; }
        
        .btn-logout {
            background-color: #e74c3c; 
            color: white; 
            border: none; 
            padding: 6px 15px;
            border-radius: 4px; 
            cursor: pointer; 
            font-weight: bold; 
            text-decoration: none; 
            font-size: 14px;
            transition: background 0.2s;
        }
        .btn-logout:hover { background-color: #c0392b; }

        .dashboard-wrapper {
            display: flex;
            flex: 1;
            height: calc(100vh - 62px);
        }

        /* Sidebar Navigation Layout styling */
        .sidebar {
            width: 260px;
            background-color: #f0f4f8; 
            border-right: 1px solid #dcdfe4;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
        }

        .sidebar-menu { list-style: none; }
        .sidebar-menu li a {
            display: block;
            padding: 14px 25px;
            color: #1a252f;
            text-decoration: none;
            font-size: 18px; 
            font-weight: 500;
        }
        .sidebar-menu li a:hover, .sidebar-menu li.active a {
            background-color: #e2e8f0;
            color: #1abc9c;
            font-weight: 600;
        }

        .main-content {
            flex: 1;
            padding: 40px;
            overflow-y: auto;
        }
        
        /* Home Layout Components */
        .welcome-banner {
            background: linear-gradient(135deg, #2c3e50, #1a252f);
            color: white; 
            padding: 40px; 
            border-radius: 8px; 
            margin-bottom: 30px;
            text-align: center;
        }
        .welcome-banner h1 { font-size: 32px; margin-bottom: 10px; }
        .welcome-banner p { font-size: 16px; color: #bdc3c7; }

        .section-title { 
            font-size: 24px; 
            margin-bottom: 20px; 
            color: #2c3e50; 
            font-weight: bold;
        }
        
        .grid-container { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
            gap: 20px; 
            margin-bottom: 35px;
        }
        
        .card {
            background: white; 
            padding: 25px; 
            text-align: center; 
            border-radius: 8px;
            border: 1px solid #e0e0e0; 
            text-decoration: none; 
            color: inherit; 
            display: block;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            transition: transform 0.2s, border-color 0.2s;
        }
        .card:hover { 
            transform: translateY(-5px); 
            border-color: #4caf50; 
        }
        .card-icon { font-size: 40px; margin-bottom: 15px; display: inline-block; }
        .card h3 { font-size: 18px; color: #2c3e50; margin-bottom: 8px; }
        .card p { font-size: 13px; color: #7f8c8d; line-height: 1.4; }

        .getting-started-box {
            background-color: #e8f5e9;
            border-left: 5px solid #4caf50;
            padding: 20px;
            border-radius: 4px;
        }
        .getting-started-box h4 { color: #2e7d32; font-size: 16px; margin-bottom: 10px; }
        .getting-started-box ol { padding-left: 20px; color: #333; font-size: 14px; line-height: 1.8; }

        /* Schools List Table View Components */
        .btn-green {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .btn-green:hover { background-color: #45a049; }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            margin-bottom: 15px;
        }
        .data-table th {
            background-color: #4caf50;
            color: white;
            text-align: left;
            padding: 12px 15px;
            font-size: 14px;
        }
        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
            vertical-align: middle;
        }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }

        .btn-action {padding: 6px 12px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 13px; color: white; display: inline-block; margin-right: 5px;}
        .btn-update { background-color: #4caf50; }
        .btn-update:hover { background-color: #45a049; }
        .btn-delete { background-color: #e74c3c; }
        .btn-delete:hover { background-color: #c0392b; }

        .table-footer-summary { font-size: 14px; color: #333; margin-top: 15px; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <div class="user-profile">
            <div class="user-info">
                <strong>Username: <?php echo htmlspecialchars($_SESSION['user']); ?></strong>
            </div>
            <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
        </div>
    </header>

    <div class="dashboard-wrapper">
        
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li class="<?php echo !isset($_GET['view']) ? 'active' : ''; ?>"><a href="dashboard.php">Home</a></li>
                <li class="<?php echo (isset($_GET['view']) && $_GET['view'] === 'schools') ? 'active' : ''; ?>"><a href="dashboard.php?view=schools">Schools</a></li>
                <li><a href="department.php">Departments</a></li>
                <li><a href="program.php">Programs</a></li>
                <li><a href="students.php">Students</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                <li><a href="users.php">Users</a></li>
                <?php endif; ?>
            </ul>
        </aside>

        <main class="main-content">
            <?php if (isset($_GET['view']) && $_GET['view'] === 'schools'): ?>
                
                <div class="section-title">School List</div>

                <a href="school.php?action=create" class="btn-green">✚ Create School Entry</a>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th style="width: 15%;">School ID</th>
                            <th style="width: 50%;">School Full Name</th>
                            <th style="width: 20%;">School Short Name</th>
                            <th style="width: 15%;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($schools) > 0): ?>
                            <?php foreach ($schools as $school): ?>
                                <tr>
                                <td>
                                    <a href="school.php?id=<?php echo $school['collid']; ?>" style="color: #4caf50; font-weight: bold; text-decoration: none;">
                                        <?php echo $school['collid']; ?>
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($school['collfullname']); ?></td>
                                <td><?php echo htmlspecialchars($school['collshortname']); ?></td>
                                <td>
                                    <a href="school.php?action=update_school&id=<?php echo $school['collid']; ?>" class="btn-action btn-update">Update</a>
                                    <a href="school.php?action=delete_school&id=<?php echo $school['collid']; ?>" class="btn-action btn-delete">Delete</a>
                                </td>
                            </tr>
                                                        <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: #7f8c8d; padding: 20px;">No schools found in the system database.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="table-footer-summary">
                    Total of: <strong><?php echo $totalColleges; ?></strong> schools in the database
                </div>

            <?php else: ?>

                <section class="welcome-banner">
                    <h1>Welcome to USJ-R School Management System</h1>
                    <p>Manage your school's operations efficiently</p>
                </section>

                <h2 class="section-title">Quick Access</h2>
                <section class="grid-container">
                    <a href="dashboard.php?view=schools" class="card">
                        <span class="card-icon">🏫</span>
                        <h3>Schools</h3>
                        <p>Manage school information and details</p>
                    </a>
                    <a href="department.php" class="card">
                        <span class="card-icon">📚</span>
                        <h3>Departments</h3>
                        <p>Organize departments within schools</p>
                    </a>
                    <a href="program.php" class="card">
                        <span class="card-icon">🎓</span>
                        <h3>Programs</h3>
                        <p>Manage academic programs and courses</p>
                    </a>
                    <a href="students.php" class="card">
                        <span class="card-icon">👥</span>
                        <h3>Students</h3>
                        <p>Manage student records and enrollment</p>
                    </a>
                </section>

                <section class="getting-started-box">
                    <h4>Getting Started</h4>
                    <ol>
                        <li>Log in with your credentials</li>
                        <li>Navigate to any section using the sidebar menu or click a card above</li>
                        <li>View, create, update, or delete records as needed</li>
                        <li>Contact administrator for access requests</li>
                    </ol>
                </section>

            <?php endif; ?>
        </main>

    </div>

</body>
</html>