<?php

$host     = 'localhost';
$db_name  = 'usjr'; 
$username = 'root';               
$password = 'mark123';                  
$charset  = 'utf8mb4';

// Data Source Name construction
$dsn = "mysql:host=$host;dbname=$db_name;charset=$charset";

// Connection error tracking configuration options
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,      
    PDO::ATTR_EMULATE_PREPARES   => false,               
];

try {
   
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    die("Database Connection Failure: " . $e->getMessage());
}
?>