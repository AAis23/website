<?php
session_start();

// 1. Protection Security Check
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

// 2. Include database configuration file
require_once 'db.php';

// Route Parameter Handlers
$action = isset($_GET['action']) ? trim($_GET['action']) : 'view';
$dept_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
// Track selected parent school filter criteria
$selected_school_id = isset($_GET['school_id']) ? intval($_GET['school_id']) : (isset($_POST['selected_school_id']) ? intval($_POST['selected_school_id']) : 0);

$message = '';
$message_type = '';

/* ==========================================
   POST ACTIONS HANDLER BLOCK
   ========================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ACTION A: SAVE NEW DEPARTMENT ENTRY
    if (isset($_POST['save_department'])) {
        $deptid = isset($_POST['deptid']) ? trim($_POST['deptid']) : '';
        $deptfullname = isset($_POST['deptfullname']) ? trim($_POST['deptfullname']) : '';
        $deptshortname = isset($_POST['deptshortname']) ? trim($_POST['deptshortname']) : '';
        $deptcollid = isset($_POST['deptcollid']) ? intval($_POST['deptcollid']) : 0;

        $school_id_string = (string)$deptcollid;
        $id_starts_with_school_id = (substr($deptid, 0, strlen($school_id_string)) === $school_id_string);

        if (empty($deptid) || empty($deptfullname) || $deptcollid <= 0) {
            $message = "Department ID, Full Name, and a parent school selection are required fields.";
            $message_type = "error";
            $action = "create"; 
        }  elseif (!is_numeric($deptid)) {
            $message = "Department ID must be a numeric integer sequence value.";
            $message_type = "error";
            $action = "create";
        } elseif (strlen($deptid) > 5) { //checks the digits
            $message = "Validation Error: Department ID cannot exceed 5 digits.";
            $message_type = "error";
            $action = "create";
        } elseif (!$id_starts_with_school_id) {
            $message = "Validation Error: Department ID must start with the prefix of the selected School ID ({$school_id_string}).";
            $message_type = "error";
            $action = "create";
        } else {
            try {
                $deptid = intval($deptid);
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE deptid = ?");
                $check_stmt->execute([$deptid]);
                
                if ($check_stmt->fetchColumn() > 0) {
                    $message = "Conflict: A department with registration ID '{$deptid}' already exists.";
                    $message_type = "error";
                    $action = "create";
                } else {
                    $insert_stmt = $pdo->prepare("INSERT INTO departments (deptid, deptfullname, deptshortname, deptcollid) VALUES (?, ?, ?, ?)");
                    $insert_stmt->execute([$deptid, $deptfullname, $deptshortname, $deptcollid]);
                    
                    header("Location: department.php?school_id=" . $deptcollid);
                    exit;
                }
            } catch (\PDOException $e) {
                $message = "Database transactional error: " . $e->getMessage();
                $message_type = "error";
                $action = "create";
            }
        }
    }

    // ACTION B: UPDATE EXISTING DEPARTMENT ENTRY
    if (isset($_POST['update_department'])) {
        $old_deptid = isset($_POST['old_deptid']) ? intval($_POST['old_deptid']) : 0;
        $new_deptid = isset($_POST['deptid']) ? trim($_POST['deptid']) : '';
        $deptfullname = isset($_POST['deptfullname']) ? trim($_POST['deptfullname']) : '';
        $deptshortname = isset($_POST['deptshortname']) ? trim($_POST['deptshortname']) : '';
        $deptcollid = isset($_POST['deptcollid']) ? intval($_POST['deptcollid']) : 0;

        $school_id_string = (string)$deptcollid;
        $id_starts_with_school_id = (substr($new_deptid, 0, strlen($school_id_string)) === $school_id_string);

        if (empty($new_deptid) || empty($deptfullname) || $deptcollid <= 0) {
            $message = "Department ID, Full Name, and a parent school selection are required fields.";
            $message_type = "error";
            $action = "update";
            $dept_id = $old_deptid;
        } elseif (!is_numeric($new_deptid)) {
            $message = "Department ID must be a numeric integer sequence value.";
            $message_type = "error";
            $action = "update";
            $dept_id = $old_deptid;
        } elseif (strlen($new_deptid) > 5) {
            $message = "Validation Error: Department ID cannot exceed 5 digits.";
            $message_type = "error";
            $action = "update";
            $dept_id = $old_deptid;
        } elseif (!$id_starts_with_school_id) {
            $message = "Validation Error: Department ID must start with the prefix of the selected School ID ({$school_id_string}).";
            $message_type = "error";
            $action = "update";
            $dept_id = $old_deptid;
        } else {
            try {
                $new_deptid = intval($new_deptid);
                
                // If ID is being altered, ensure no uniqueness conflicts exist
                if ($old_deptid !== $new_deptid) {
                    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE deptid = ?");
                    $check_stmt->execute([$new_deptid]);
                    if ($check_stmt->fetchColumn() > 0) {
                        throw new Exception("Conflict: A department with registration ID '{$new_deptid}' already exists.");
                    }
                }

                $update_stmt = $pdo->prepare("UPDATE departments SET deptid = ?, deptfullname = ?, deptshortname = ?, deptcollid = ? WHERE deptid = ?");
                $update_stmt->execute([$new_deptid, $deptfullname, $deptshortname, $deptcollid, $old_deptid]);
                
                header("Location: department.php?school_id=" . $deptcollid);
                exit;
            } catch (\Exception $e) {
                $message = "Database transactional error: " . $e->getMessage();
                $message_type = "error";
                $action = "update";
                $dept_id = $old_deptid;
            }
        }
    }

    // ACTION C: CONFIRM DELETE DEPARTMENT RECORD
    if (isset($_POST['confirm_delete_dept'])) {
        try {
            $check_programs = $pdo->prepare("SELECT COUNT(*) FROM programs WHERE progcolldeptid = ?");
            $check_programs->execute([$dept_id]);
            $check_students = $pdo->prepare("SELECT COUNT(*) FROM students WHERE studcolldeptid = ?");
            $check_students->execute([$dept_id]);

            if ($check_programs->fetchColumn() > 0 || $check_students->fetchColumn() > 0) {
                $message = "Cannot remove this department. Active academic programs or enrolled students are assigned to it.";
                $message_type = "error";
                $action = "delete";
            } else {
                $delete_stmt = $pdo->prepare("DELETE FROM departments WHERE deptid = ?");
                $delete_stmt->execute([$dept_id]);
                header("Location: department.php?school_id=" . $selected_school_id);
                exit;
            }
        } catch (\PDOException $e) {
            $message = "Database delete operation failure: " . $e->getMessage();
            $message_type = "error";
            $action = "delete";
        }
    }
}

/* ==========================================
   DATA LOOKUP RESOLUTION BLOCK (GET ROUTING)
   ========================================== */
$schools = [];
$department = null;
$departments = [];
$selected_school_info = null;
$total_departments = 0;
$total_pages = 1;
$current_page = 1;

// Global: Fetch all schools to satisfy filtering selectors across layouts
try {
    $schools_stmt = $pdo->query("SELECT collid, collfullname, collshortname FROM colleges ORDER BY collshortname ASC");
    $schools = $schools_stmt->fetchAll();
} catch (\PDOException $e) {
    die("Dropdown core context loading failure: " . $e->getMessage());
}

// Fetch active contextual profile info if a school filter index parameter is provided
if ($selected_school_id > 0) {
    foreach ($schools as $s) {
        if ($s['collid'] == $selected_school_id) {
            $selected_school_info = $s;
            break;
        }
    }
}

// Load department record context if deleting or updating
if (($action === 'delete' || $action === 'update') && $dept_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM departments WHERE deptid = ?");
    $stmt->execute([$dept_id]);
    $department = $stmt->fetch();
    if (!$department) {
        header("Location: department.php");
        exit;
    }
    $selected_school_id = $department['deptcollid'];
}

// Default View: Load departments filtering matching school index criteria
if ($action === 'view' && $selected_school_id > 0) {
    $limit = 6;
    $current_page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
    $offset = ($current_page - 1) * $limit;

    try {
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM departments WHERE deptcollid = ?");
        $count_stmt->execute([$selected_school_id]);
        $total_departments = $count_stmt->fetchColumn();
        $total_pages = ceil($total_departments / $limit);

        $dept_stmt = $pdo->prepare("
            SELECT d.deptid, d.deptfullname, d.deptshortname, d.deptcollid, c.collshortname 
            FROM departments d
            LEFT JOIN colleges c ON d.deptcollid = c.collid
            WHERE d.deptcollid = ?
            ORDER BY d.deptid ASC LIMIT ? OFFSET ?
        ");
        $dept_stmt->bindValue(1, $selected_school_id, PDO::PARAM_INT);
        $dept_stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $dept_stmt->bindValue(3, $offset, PDO::PARAM_INT);
        $dept_stmt->execute();
        $departments = $dept_stmt->fetchAll();
    } catch (\PDOException $e) {
        die("Database communications failure: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departments Filter Management Hub</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background-color: #f8f9fa; color: #333; height: 100vh; display: flex; flex-direction: column; overflow: hidden; }
        
        .navbar { background-color: #1a252f; color: #ffffff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        .navbar-brand { font-size: 24px; font-weight: bold; }
        .btn-logout { background-color: #e74c3c; color: white; padding: 6px 15px; border-radius: 4px; text-decoration: none; font-weight: bold; font-size: 14px; }

        .dashboard-wrapper { display: flex; flex: 1; height: calc(100vh - 62px); }
        .sidebar { width: 260px; background-color: #f0f4f8; border-right: 1px solid #dcdfe4; padding-top: 20px; }
        .sidebar-menu { list-style: none; }
        .sidebar-menu li a { display: block; padding: 14px 25px; color: #1a252f; text-decoration: none; font-size: 18px; font-weight: 500; }
        .sidebar-menu li a:hover, .sidebar-menu li.active a { background-color: #e2e8f0; color: #1abc9c; font-weight: 600; }

        .main-content { flex: 1; padding: 40px; overflow-y: auto; }
        .module-header { font-size: 22px; font-weight: bold; color: #000; margin-bottom: 25px; }
        .warn-notice { font-size: 16px; color: #000; margin-bottom: 20px; }

        .filter-panel-card { background: white; border: 1px solid #dcdfe4; border-radius: 8px; padding: 25px; max-width: 700px; margin-bottom: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .filter-title-prompt { font-size: 16px; color: #2c3e50; font-weight: 500; margin-bottom: 12px; }
        .filter-inline-form { display: flex; gap: 10px; }
        .select-filter-control { flex: 1; padding: 10px 14px; font-size: 15px; border: 1px solid #ccc; border-radius: 6px; outline: none; background-color: #fff; cursor: pointer; }
        .btn-filter-go { background-color: #1abc9c; color: white; border: none; padding: 10px 24px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 15px; }
        .btn-filter-go:hover { background-color: #16a085; }

        .form-row { display: flex; align-items: center; margin-bottom: 20px; max-width: 900px; }
        .form-label { width: 220px; font-size: 18px; color: #000; font-weight: 500; }
        .form-control { flex: 1; padding: 10px 14px; font-size: 16px; border: 1px solid #ccc; border-radius: 6px; outline: none; background-color: #fff; }
        .form-actions-bar { display: flex; gap: 12px; margin-top: 30px; padding-left: 220px; }

        .btn-green { background-color: #4caf50; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; text-decoration: none; display: inline-block; margin-bottom: 20px; font-size: 14px; border: none; }
        .data-table { width: 100%; border-collapse: collapse; background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 15px; }
        .data-table th { background-color: #4caf50; color: white; text-align: left; padding: 12px 15px; font-size: 14px; }
        .data-table td { padding: 12px 15px; border-bottom: 1px solid #e0e0e0; font-size: 14px; color: #000; }
        .data-table tr:nth-child(even) { background-color: #f9f9f9; }
        
        .btn-action { padding: 5px 10px; border-radius: 3px; text-decoration: none; font-weight: bold; font-size: 12px; color: white; display: inline-block; margin-right: 5px; }
        .btn-update { background-color: #4caf50; }
        .btn-delete { background-color: #e74c3c; }
        
        .btn-submit { background-color: #e0e0e0; color: #000; border: 1px solid #adadad; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn-reset { background-color: #bfbfbf; color: #000; border: 1px solid #9c9c9c; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn-exit, .btn-confirm-red, .btn-cancel-green { border: none; padding: 10px 24px; border-radius: 4px; cursor: pointer; font-size: 16px; font-weight: bold; text-decoration: none; display: inline-block; text-align: center; }
        .btn-exit { background-color: #e74c3c; color: #fff; }
        .btn-confirm-red { background-color: #e74c3c; color: #fff; padding: 10px 20px; font-size: 15px; }
        .btn-cancel-green { background-color: #4caf50; color: #fff; padding: 10px 20px; font-size: 15px; }

        .confirmation-table { width: 100%; max-width: 650px; border-collapse: collapse; background-color: #fff; margin-bottom: 25px; }
        .confirmation-table td { border: 1px solid #666; padding: 10px 15px; font-size: 15px; color: #000; }
        .confirmation-table td.label-cell { width: 30%; font-weight: bold; }
        .prompt-text { font-size: 16px; font-weight: 500; color: #000; margin-bottom: 15px; }
        .relationship-subtext { font-size: 14px; color: #333; line-height: 1.5; margin-bottom: 25px; }

        .alert-banner { padding: 12px 15px; border-radius: 4px; margin-bottom: 20px; font-size: 14px; font-weight: bold; max-width: 900px; }
        .alert-banner.error { background-color: #fde8e8; color: #e74c3c; border: 1px solid #f8b4b4; }
        
        .pagination-container { display: flex; justify-content: space-between; align-items: center; margin-top: 20px; font-size: 14px; color: #555; }
        .pagination-buttons { display: flex; gap: 5px; }
        .page-link { padding: 6px 12px; border: 1px solid #ccc; background-color: white; color: #333; text-decoration: none; border-radius: 4px; }
        .page-link.active { background-color: #4caf50; color: white; border-color: #4caf50; font-weight: bold; }
    </style>
</head>
<body>

    <header class="navbar">
        <div class="navbar-brand">USJ-R School Management System v1.01</div>
        <a href="dashboard.php?action=logout" class="btn-logout">Logout</a>
    </header>

    <div class="dashboard-wrapper">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="dashboard.php?view=schools">Schools</a></li>
                <li class="active"><a href="department.php">Departments</a></li>
                <li><a href="program.php">Programs</a></li>
                <li><a href="students.php">Students</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                <li><a href="users.php">Users</a></li>
              <?php endif; ?>
            </ul>
        </aside>

        <main class="main-content">
            
            <?php if (!empty($message)): ?>
                <div class="alert-banner <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if ($action === 'create'): ?>
                <div class="module-header">Department Create</div>
                <form action="department.php?action=create" method="POST">
                    
                    <div class="form-row">
                        <label class="form-label" for="deptcollid">Parent School:</label>
                        <select class="form-control" id="deptcollid" name="deptcollid" required>
                            <option value="" disabled selected>-- Select Parent School Relationship --</option>
                            <?php foreach ($schools as $school): ?>
                                <option value="<?php echo $school['collid']; ?>" <?php echo ($selected_school_id == $school['collid'] || (isset($_POST['deptcollid']) && $_POST['deptcollid'] == $school['collid'])) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($school['collshortname']); ?> (ID: <?php echo $school['collid']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <label class="form-label" for="deptid">Department ID:</label>
                        <input class="form-control" type="text" id="deptid" name="deptid" placeholder="Must begin with the selected School ID value" value="<?php echo isset($_POST['deptid']) ? htmlspecialchars($_POST['deptid']) : ''; ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="deptfullname">Department Full Name:</label>
                        <input class="form-control" type="text" id="deptfullname" name="deptfullname" value="<?php echo isset($_POST['deptfullname']) ? htmlspecialchars($_POST['deptfullname']) : ''; ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="deptshortname">Department Short Name:</label>
                        <input class="form-control" type="text" id="deptshortname" name="deptshortname" placeholder="(Optional)" value="<?php echo isset($_POST['deptshortname']) ? htmlspecialchars($_POST['deptshortname']) : ''; ?>" autocomplete="off">
                    </div>

                    <div class="form-actions-bar">
                        <button class="btn-submit" type="submit" name="save_department">Save New Department Entry</button>
                        <button class="btn-reset" type="reset">Reset Form</button>
                        <a class="btn-exit" href="department.php?school_id=<?php echo $selected_school_id; ?>">Exit</a>
                    </div>
                </form>

            <?php elseif ($action === 'update' && $department): ?>
                <div class="module-header">Department Update</div>
                <form action="department.php?action=update&id=<?php echo $dept_id; ?>" method="POST">
                    <input type="hidden" name="old_deptid" value="<?php echo htmlspecialchars($department['deptid']); ?>">
                    
                    <div class="form-row">
                        <label class="form-label" for="deptcollid">Parent School:</label>
                        <select class="form-control" id="deptcollid" name="deptcollid" required>
                            <option value="" disabled>-- Select Parent School Relationship --</option>
                            <?php foreach ($schools as $school): ?>
                                <option value="<?php echo $school['collid']; ?>" <?php echo ($department['deptcollid'] == $school['collid']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($school['collshortname']); ?> (ID: <?php echo $school['collid']; ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-row">
                        <label class="form-label" for="deptid">Department ID:</label>
                        <input class="form-control" type="text" id="deptid" name="deptid" value="<?php echo htmlspecialchars($department['deptid']); ?>" required autocomplete="off">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="deptfullname">Department Full Name:</label>
                        <input class="form-control" type="text" id="deptfullname" name="deptfullname" value="<?php echo htmlspecialchars($department['deptfullname']); ?>" required autocomplete="off">
                    </div>
                    
                    <div class="form-row">
                        <label class="form-label" for="deptshortname">Department Short Name:</label>
                        <input class="form-control" type="text" id="deptshortname" name="deptshortname" value="<?php echo htmlspecialchars($department['deptshortname']); ?>" autocomplete="off">
                    </div>

                    <div class="form-actions-bar">
                        <button class="btn-submit" type="submit" name="update_department">Update Department Entry</button>
                        <button class="btn-reset" type="reset">Reset Form</button>
                        <a class="btn-exit" href="department.php?school_id=<?php echo $selected_school_id; ?>">Exit</a>
                    </div>
                </form>

            <?php elseif ($action === 'delete' && $department): ?>
                <div class="warn-notice">You are about to delete the following department entry:</div>
                <table class="confirmation-table">
                    <tr><td class="label-cell">Department ID:</td><td><?php echo htmlspecialchars($department['deptid']); ?></td></tr>
                    <tr><td class="label-cell">Department Full Name:</td><td><?php echo htmlspecialchars($department['deptfullname']); ?></td></tr>
                    <tr><td class="label-cell">Department Short Name:</td><td><?php echo htmlspecialchars(!empty($department['deptshortname']) ? $department['deptshortname'] : '—'); ?></td></tr>
                </table>
                <div class="prompt-text">Are you sure you want to delete this department entry?</div>
                <div class="relationship-subtext">This entry is part of a high-level relationship in the database.<br>Deleting this entry may affect related data.</div>
                <form action="department.php?action=delete&id=<?php echo $dept_id; ?>&school_id=<?php echo $selected_school_id; ?>" method="POST">
                    <div class="action-button-group">
                        <button type="submit" name="confirm_delete_dept" class="btn-confirm-red">Yes, Delete Entry</button>
                        <a href="department.php?school_id=<?php echo $selected_school_id; ?>" class="btn-cancel-green">No, Cancel</a>
                    </div>
                </form>

            <?php else: ?>
                <div class="module-header">System Directory: Registered Departments</div>

                <div class="filter-panel-card">
                    <div class="filter-title-prompt">Please choose a school first to see the departments inside it.</div>
                    <form action="department.php" method="GET" class="filter-inline-form">
                        <select name="school_id" class="select-filter-control" required>
                            <option value="" disabled <?php echo ($selected_school_id === 0) ? 'selected' : ''; ?>>-- Select School View Filter --</option>
                            <?php foreach ($schools as $school): ?>
                                <option value="<?php echo $school['collid']; ?>" <?php echo ($selected_school_id === (int)$school['collid']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($school['collfullname']); ?> (<?php echo htmlspecialchars($school['collshortname']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn-filter-go">Load Directory</button>
                    </form>
                </div>

                <?php if ($selected_school_id > 0 && $selected_school_info): ?>
                    
                    <div style="margin-bottom: 15px; font-size: 16px; color: #000;">
                        Currently viewing departments inside: <strong><?php echo htmlspecialchars($selected_school_info['collfullname']); ?> (<?php echo htmlspecialchars($selected_school_info['collshortname']); ?>)</strong>
                    </div>

                    <a href="department.php?action=create&school_id=<?php echo $selected_school_id; ?>" class="btn-green">⊕ Create Department Entry</a>

                    <table class="data-table">
                        <thead>
                            <tr>
                                <th style="width: 15%;">Department ID</th>
                                <th style="width: 50%;">Department Full Name</th>
                                <th style="width: 20%;">Department Short Name</th>
                                <th style="width: 15%;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($departments) > 0): ?>
                                <?php foreach ($departments as $dept): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($dept['deptid']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($dept['deptfullname']); ?></td>
                                        <td><?php echo htmlspecialchars(!empty($dept['deptshortname']) ? $dept['deptshortname'] : '—'); ?></td>
                                        <td>
                                            <a href="department.php?action=update&id=<?php echo $dept['deptid']; ?>" class="btn-action btn-update">Update</a>
                                            <a href="department.php?action=delete&id=<?php echo $dept['deptid']; ?>" class="btn-action btn-delete">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" style="text-align: center; color: #7f8c8d; padding: 25px;">No active department entries discovered under this school tracking selection.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="pagination-container">
                        <div>Total of: <strong><?php echo $total_departments; ?></strong> registered department entries inside selection.</div>
                        
                        <?php if ($total_pages > 1): ?>
                            <div class="pagination-buttons">
                                <?php if ($current_page > 1): ?>
                                    <a href="department.php?school_id=<?php echo $selected_school_id; ?>&p=<?php echo $current_page - 1; ?>" class="page-link">« Prev</a>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <a href="department.php?school_id=<?php echo $selected_school_id; ?>&p=<?php echo $i; ?>" class="page-link <?php echo ($i === $current_page) ? 'active' : ''; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor; ?>

                                <?php if ($current_page < $total_pages): ?>
                                    <a href="department.php?school_id=<?php echo $selected_school_id; ?>&p=<?php echo $current_page + 1; ?>" class="page-link">Next »</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                <?php endif; ?>
            <?php endif; ?>
        </main>
    </div>

</body>
</html>